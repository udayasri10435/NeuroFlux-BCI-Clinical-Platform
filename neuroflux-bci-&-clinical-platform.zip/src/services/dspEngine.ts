/**
 * Digital Signal Processing (DSP) & Biosignal Synthesis Engine
 * Provides IIR filtering, FFT spectral estimation, ERP epoching,
 * and realistic EEG/EMG multi-channel biosignal synthesis.
 */

export interface ChannelInfo {
  id: string;
  name: string;
  type: 'EEG' | 'EMG';
  lobe?: 'Frontal' | 'Central' | 'Parietal' | 'Occipital' | 'Temporal' | 'Muscle';
  x: number; // 2D normalized coordinate [-1, 1]
  y: number; // 2D normalized coordinate [-1, 1]
  color: string;
  impedanceKOhms: number; // e.g. 2.1 kOhm
  gainScale: number; // multiplier for visual display
  visible: boolean;
}

export interface MarkerEvent {
  id: string;
  timestampMs: number;
  label: string;
  code: number;
  type: 'stimulus' | 'artifact' | 'clinical' | 'motor';
  description: string;
}

export interface SpectralBandInfo {
  name: string;
  freqRange: [number, number];
  color: string;
  power: number;
  relativePower: number; // percentage 0-100
}

export interface FilterConfig {
  notch50Hz: boolean;
  notch60Hz: boolean;
  highPassCutoff: number; // e.g. 0.5 Hz
  lowPassCutoff: number;  // e.g. 45 Hz
  enableBandpass: boolean;
  detrend: boolean;
  emgEnvelope: boolean;
}

export const STANDARD_10_20_EEG_CHANNELS: ChannelInfo[] = [
  { id: 'Fp1', name: 'Fp1', type: 'EEG', lobe: 'Frontal', x: -0.3, y: -0.85, color: '#38BDF8', impedanceKOhms: 3.2, gainScale: 1.0, visible: true },
  { id: 'Fp2', name: 'Fp2', type: 'EEG', lobe: 'Frontal', x: 0.3, y: -0.85, color: '#38BDF8', impedanceKOhms: 2.8, gainScale: 1.0, visible: true },
  { id: 'F3',  name: 'F3',  type: 'EEG', lobe: 'Frontal', x: -0.45, y: -0.5, color: '#60A5FA', impedanceKOhms: 4.1, gainScale: 1.0, visible: true },
  { id: 'F4',  name: 'F4',  type: 'EEG', lobe: 'Frontal', x: 0.45, y: -0.5, color: '#60A5FA', impedanceKOhms: 3.9, gainScale: 1.0, visible: true },
  { id: 'C3',  name: 'C3',  type: 'EEG', lobe: 'Central', x: -0.5, y: 0.0, color: '#A78BFA', impedanceKOhms: 2.4, gainScale: 1.0, visible: true },
  { id: 'Cz',  name: 'Cz',  type: 'EEG', lobe: 'Central', x: 0.0, y: 0.0, color: '#C084FC', impedanceKOhms: 1.9, gainScale: 1.0, visible: true },
  { id: 'C4',  name: 'C4',  type: 'EEG', lobe: 'Central', x: 0.5, y: 0.0, color: '#A78BFA', impedanceKOhms: 2.2, gainScale: 1.0, visible: true },
  { id: 'P3',  name: 'P3',  type: 'EEG', lobe: 'Parietal', x: -0.45, y: 0.5, color: '#F472B6', impedanceKOhms: 4.5, gainScale: 1.0, visible: true },
  { id: 'Pz',  name: 'Pz',  type: 'EEG', lobe: 'Parietal', x: 0.0, y: 0.5, color: '#FB7185', impedanceKOhms: 3.1, gainScale: 1.0, visible: true },
  { id: 'P4',  name: 'P4',  type: 'EEG', lobe: 'Parietal', x: 0.45, y: 0.5, color: '#F472B6', impedanceKOhms: 3.8, gainScale: 1.0, visible: true },
  { id: 'O1',  name: 'O1',  type: 'EEG', lobe: 'Occipital', x: -0.3, y: 0.85, color: '#34D399', impedanceKOhms: 2.9, gainScale: 1.0, visible: true },
  { id: 'O2',  name: 'O2',  type: 'EEG', lobe: 'Occipital', x: 0.3, y: 0.85, color: '#34D399', impedanceKOhms: 3.0, gainScale: 1.0, visible: true },
];

export const STANDARD_EMG_CHANNELS: ChannelInfo[] = [
  { id: 'EMG1', name: 'Biceps Brachii (L)', type: 'EMG', lobe: 'Muscle', x: -0.6, y: -0.2, color: '#F59E0B', impedanceKOhms: 4.8, gainScale: 1.0, visible: true },
  { id: 'EMG2', name: 'Biceps Brachii (R)', type: 'EMG', lobe: 'Muscle', x: 0.6, y: -0.2, color: '#F59E0B', impedanceKOhms: 4.2, gainScale: 1.0, visible: true },
  { id: 'EMG3', name: 'Flexor Carpi (L)',   type: 'EMG', lobe: 'Muscle', x: -0.7, y: 0.4, color: '#EAB308', impedanceKOhms: 5.1, gainScale: 1.0, visible: true },
  { id: 'EMG4', name: 'Flexor Carpi (R)',   type: 'EMG', lobe: 'Muscle', x: 0.7, y: 0.4, color: '#EAB308', impedanceKOhms: 3.9, gainScale: 1.0, visible: true },
];

// Discrete Biquad Filter Coefficients for IIR filtering
class BiquadFilter {
  private b0 = 1; private b1 = 0; private b2 = 0;
  private a1 = 0; private a2 = 0;
  private x1 = 0; private x2 = 0;
  private y1 = 0; private y2 = 0;

  constructor() {
    this.reset();
  }

  reset() {
    this.x1 = 0; this.x2 = 0;
    this.y1 = 0; this.y2 = 0;
  }

  setNotch(f0: number, fs: number, Q: number = 30) {
    const w0 = 2 * Math.PI * f0 / fs;
    const alpha = Math.sin(w0) / (2 * Q);
    const b0 = 1;
    const b1 = -2 * Math.cos(w0);
    const b2 = 1;
    const a0 = 1 + alpha;
    const a1 = -2 * Math.cos(w0);
    const a2 = 1 - alpha;

    this.b0 = b0 / a0;
    this.b1 = b1 / a0;
    this.b2 = b2 / a0;
    this.a1 = a1 / a0;
    this.a2 = a2 / a0;
  }

  setLowPass(fc: number, fs: number, Q: number = 0.707) {
    const w0 = 2 * Math.PI * fc / fs;
    const alpha = Math.sin(w0) / (2 * Q);
    const cosw0 = Math.cos(w0);
    const b0 = (1 - cosw0) / 2;
    const b1 = 1 - cosw0;
    const b2 = (1 - cosw0) / 2;
    const a0 = 1 + alpha;
    const a1 = -2 * cosw0;
    const a2 = 1 - alpha;

    this.b0 = b0 / a0;
    this.b1 = b1 / a0;
    this.b2 = b2 / a0;
    this.a1 = a1 / a0;
    this.a2 = a2 / a0;
  }

  setHighPass(fc: number, fs: number, Q: number = 0.707) {
    const w0 = 2 * Math.PI * fc / fs;
    const alpha = Math.sin(w0) / (2 * Q);
    const cosw0 = Math.cos(w0);
    const b0 = (1 + cosw0) / 2;
    const b1 = -(1 + cosw0);
    const b2 = (1 + cosw0) / 2;
    const a0 = 1 + alpha;
    const a1 = -2 * cosw0;
    const a2 = 1 - alpha;

    this.b0 = b0 / a0;
    this.b1 = b1 / a0;
    this.b2 = b2 / a0;
    this.a1 = a1 / a0;
    this.a2 = a2 / a0;
  }

  process(x: number): number {
    const y = this.b0 * x + this.b1 * this.x1 + this.b2 * this.x2 - this.a1 * this.y1 - this.a2 * this.y2;
    this.x2 = this.x1;
    this.x1 = x;
    this.y2 = this.y1;
    this.y1 = y;
    return isNaN(y) ? x : y;
  }
}

/**
 * Multi-stage channel filter pipeline
 */
export class ChannelFilterPipeline {
  private notch50 = new BiquadFilter();
  private notch60 = new BiquadFilter();
  private highPass = new BiquadFilter();
  private lowPass = new BiquadFilter();
  private rmsWindow: number[] = [];
  private readonly rmsSize = 25;

  constructor(fs: number = 500) {
    this.updateConfig(
      {
        notch50Hz: true,
        notch60Hz: false,
        highPassCutoff: 0.5,
        lowPassCutoff: 45,
        enableBandpass: true,
        detrend: true,
        emgEnvelope: false,
      },
      fs
    );
  }

  updateConfig(config: FilterConfig, fs: number) {
    this.notch50.setNotch(50, fs, 25);
    this.notch60.setNotch(60, fs, 25);
    this.highPass.setHighPass(Math.max(0.1, config.highPassCutoff), fs);
    this.lowPass.setLowPass(Math.min(fs * 0.48, config.lowPassCutoff), fs);
  }

  filterSample(rawVal: number, config: FilterConfig): number {
    let val = rawVal;
    if (config.detrend && config.highPassCutoff > 0) {
      val = this.highPass.process(val);
    }
    if (config.enableBandpass) {
      val = this.lowPass.process(val);
    }
    if (config.notch50Hz) {
      val = this.notch50.process(val);
    }
    if (config.notch60Hz) {
      val = this.notch60.process(val);
    }
    if (config.emgEnvelope) {
      this.rmsWindow.push(val * val);
      if (this.rmsWindow.length > this.rmsSize) {
        this.rmsWindow.shift();
      }
      const meanSquare = this.rmsWindow.reduce((a, b) => a + b, 0) / this.rmsWindow.length;
      return Math.sqrt(meanSquare);
    }
    return val;
  }
}

/**
 * Fast Fourier Transform (Cooley-Tukey Radix-2)
 */
export function computeFFT(realInput: number[]): { freqs: number[]; magnitudes: number[] } {
  // Ensure power of 2
  let n = 1;
  while (n * 2 <= realInput.length && n * 2 <= 512) {
    n *= 2;
  }
  const xReal = new Float64Array(n);
  const xImag = new Float64Array(n);

  // Apply Hann window
  for (let i = 0; i < n; i++) {
    const window = 0.5 * (1 - Math.cos((2 * Math.PI * i) / (n - 1)));
    xReal[i] = realInput[realInput.length - n + i] * window;
    xImag[i] = 0;
  }

  // Bit reversal permutation
  let j = 0;
  for (let i = 0; i < n - 1; i++) {
    if (i < j) {
      const tempR = xReal[i]; xReal[i] = xReal[j]; xReal[j] = tempR;
      const tempI = xImag[i]; xImag[i] = xImag[j]; xImag[j] = tempI;
    }
    let k = n >> 1;
    while (k <= j) {
      j -= k;
      k >>= 1;
    }
    j += k;
  }

  // Cooley-Tukey butterfly
  for (let len = 2; len <= n; len <<= 1) {
    const halfLen = len >> 1;
    const angle = (-2 * Math.PI) / len;
    const wStepR = Math.cos(angle);
    const wStepI = Math.sin(angle);

    for (let i = 0; i < n; i += len) {
      let wR = 1;
      let wI = 0;
      for (let k = 0; k < halfLen; k++) {
        const uR = xReal[i + k];
        const uI = xImag[i + k];
        const vR = xReal[i + k + halfLen] * wR - xImag[i + k + halfLen] * wI;
        const vI = xReal[i + k + halfLen] * wI + xImag[i + k + halfLen] * wR;

        xReal[i + k] = uR + vR;
        xImag[i + k] = uI + vI;
        xReal[i + k + halfLen] = uR - vR;
        xImag[i + k + halfLen] = uI - vI;

        const nextWR = wR * wStepR - wI * wStepI;
        wI = wR * wStepI + wI * wStepR;
        wR = nextWR;
      }
    }
  }

  const samplingRate = 250; // standard display fs
  const halfN = n / 2;
  const freqs: number[] = [];
  const magnitudes: number[] = [];

  for (let i = 0; i < halfN; i++) {
    const freq = (i * samplingRate) / n;
    const mag = (2 * Math.sqrt(xReal[i] * xReal[i] + xImag[i] * xImag[i])) / n;
    freqs.push(freq);
    magnitudes.push(mag);
  }

  return { freqs, magnitudes };
}

/**
 * Compute Standard EEG Spectral Bands
 */
export function calculateSpectralBands(freqs: number[], magnitudes: number[]): SpectralBandInfo[] {
  const bands = [
    { name: 'Delta', range: [0.5, 4] as [number, number], color: '#6366F1' },
    { name: 'Theta', range: [4, 8] as [number, number], color: '#38BDF8' },
    { name: 'Alpha', range: [8, 13] as [number, number], color: '#10B981' },
    { name: 'Beta', range: [13, 30] as [number, number], color: '#F59E0B' },
    { name: 'Gamma', range: [30, 60] as [number, number], color: '#EC4899' },
  ];

  const bandPowers: { name: string; freqRange: [number, number]; color: string; power: number }[] = [];
  let totalPower = 0;

  for (const b of bands) {
    let power = 0;
    let count = 0;
    for (let i = 0; i < freqs.length; i++) {
      if (freqs[i] >= b.range[0] && freqs[i] < b.range[1]) {
        power += magnitudes[i] * magnitudes[i];
        count++;
      }
    }
    const avgPower = count > 0 ? power : 0.001;
    totalPower += avgPower;
    bandPowers.push({
      name: b.name,
      freqRange: b.range,
      color: b.color,
      power: avgPower,
    });
  }

  return bandPowers.map((bp) => ({
    ...bp,
    relativePower: totalPower > 0 ? (bp.power / totalPower) * 100 : 20,
  }));
}

/**
 * Realistic Physiological Signal Generator
 * Generates alpha bursts (occipital), mu suppression (central), P300 deflections,
 * ocular blink artifacts, 50Hz mains hum, and high-frequency EMG bursts.
 */
export class BiosignalGenerator {
  private timeSec = 0;
  private samplingRate: number;
  private blinkTimer = 0;
  private isBlinking = false;
  private motorImageryState: 'none' | 'left' | 'right' = 'none';
  private oddballCounter = 0;
  private lastStimulusTime = -10;
  private lastStimulusType: 'standard' | 'oddball' = 'standard';
  private emgContraction = 0; // 0 to 1

  constructor(samplingRate: number = 250) {
    this.samplingRate = samplingRate;
  }

  setMotorImagery(state: 'none' | 'left' | 'right') {
    this.motorImageryState = state;
  }

  setEmgContraction(level: number) {
    this.emgContraction = Math.max(0, Math.min(1, level));
  }

  triggerP300Stimulus(isOddball: boolean) {
    this.lastStimulusTime = this.timeSec;
    this.lastStimulusType = isOddball ? 'oddball' : 'standard';
  }

  triggerBlink() {
    this.isBlinking = true;
    this.blinkTimer = 0.25; // 250ms blink artifact
  }

  step(dtSec: number): {
    timestampMs: number;
    channelValues: Record<string, number>;
    event?: MarkerEvent;
  } {
    this.timeSec += dtSec;
    const t = this.timeSec;
    const fs = this.samplingRate;

    // Blink artifact clock
    let blinkArtifact = 0;
    if (this.blinkTimer > 0) {
      this.blinkTimer -= dtSec;
      const progress = 1 - this.blinkTimer / 0.25;
      blinkArtifact = Math.sin(progress * Math.PI) * 75.0; // 75 uV positive deflection
    } else {
      // Natural blink every 4-6 seconds
      if (Math.random() < 0.002) {
        this.blinkTimer = 0.25;
      }
    }

    // P300 Waveform generation (+300ms post-stimulus peak)
    let p300Deflection = 0;
    const timeSinceStim = t - this.lastStimulusTime;
    if (timeSinceStim >= 0 && timeSinceStim <= 0.8) {
      if (this.lastStimulusType === 'oddball') {
        // Late positive complex (P3b) peaking at ~320ms, width 120ms
        const peakT = 0.32;
        const sigma = 0.08;
        p300Deflection = 18.0 * Math.exp(-Math.pow(t - this.lastStimulusTime - peakT, 2) / (2 * sigma * sigma));
      } else {
        // Standard small N100 / P200 sensory response
        const n100 = -4.0 * Math.exp(-Math.pow(t - this.lastStimulusTime - 0.1, 2) / (2 * 0.03 * 0.03));
        const p200 = 5.0 * Math.exp(-Math.pow(t - this.lastStimulusTime - 0.2, 2) / (2 * 0.04 * 0.04));
        p300Deflection = n100 + p200;
      }
    }

    // Auto oddball auditory generator every ~1.2s
    let newEvent: MarkerEvent | undefined;
    this.oddballCounter += dtSec;
    if (this.oddballCounter >= 1.25) {
      this.oddballCounter = 0;
      const isOdd = Math.random() < 0.22; // 22% rare oddball
      this.triggerP300Stimulus(isOdd);
      newEvent = {
        id: `ev-${Math.floor(t * 1000)}`,
        timestampMs: Math.floor(t * 1000),
        label: isOdd ? 'TARGET S2 (1000Hz)' : 'NON-TARGET S1 (500Hz)',
        code: isOdd ? 102 : 101,
        type: 'stimulus',
        description: isOdd ? 'Rare target auditory tone (P300 elicit)' : 'Frequent baseline tone',
      };
    }

    const channelValues: Record<string, number> = {};

    // 1. EEG Channels
    const pinkNoise = (Math.random() - 0.5) * 6; // Pink baseline background
    const mains50 = Math.sin(2 * Math.PI * 50 * t) * 4.5; // 50 Hz powerline hum

    // Alpha rhythm (8-12 Hz) prominent in Occipital (O1, O2)
    const alphaOccipital = Math.sin(2 * Math.PI * 10.2 * t) * 16.0 + Math.sin(2 * Math.PI * 9.8 * t + 0.5) * 8.0;

    // Mu rhythm (9-11 Hz) and Beta (18-24 Hz) for Motor Cortex (C3, C4)
    // Left hand imagery -> contralateral C4 desynchronization (amplitude drops), C3 maintains/synchronizes
    // Right hand imagery -> contralateral C3 desynchronization, C4 maintains
    let c3MuAmp = 12.0;
    let c4MuAmp = 12.0;
    if (this.motorImageryState === 'left') {
      c4MuAmp = 3.0; // ERD contralateral
      c3MuAmp = 15.0; // ERS ipsilateral
    } else if (this.motorImageryState === 'right') {
      c3MuAmp = 3.0; // ERD contralateral
      c4MuAmp = 15.0; // ERS ipsilateral
    }

    const muC3 = Math.sin(2 * Math.PI * 10.0 * t) * c3MuAmp + Math.sin(2 * Math.PI * 21.0 * t) * (c3MuAmp * 0.4);
    const muC4 = Math.sin(2 * Math.PI * 10.0 * t + 0.3) * c4MuAmp + Math.sin(2 * Math.PI * 21.0 * t + 0.3) * (c4MuAmp * 0.4);

    // Frontal Channels (Fp1, Fp2, F3, F4)
    channelValues['Fp1'] = pinkNoise + mains50 + blinkArtifact + Math.sin(2 * Math.PI * 6.0 * t) * 4.0;
    channelValues['Fp2'] = pinkNoise * 0.95 + mains50 + blinkArtifact * 0.96 + Math.sin(2 * Math.PI * 6.0 * t + 0.2) * 4.2;
    channelValues['F3']  = pinkNoise + mains50 * 0.8 + blinkArtifact * 0.25 + Math.sin(2 * Math.PI * 10.1 * t) * 8.0;
    channelValues['F4']  = pinkNoise * 1.05 + mains50 * 0.8 + blinkArtifact * 0.25 + Math.sin(2 * Math.PI * 10.1 * t) * 7.5;

    // Central Channels (C3, Cz, C4)
    channelValues['C3'] = pinkNoise + mains50 * 0.5 + muC3;
    channelValues['Cz'] = pinkNoise + mains50 * 0.6 + p300Deflection * 0.75 + Math.sin(2 * Math.PI * 9.5 * t) * 6.0;
    channelValues['C4'] = pinkNoise + mains50 * 0.5 + muC4;

    // Parietal Channels (P3, Pz, P4) - Pz shows maximal P300
    channelValues['P3'] = pinkNoise + mains50 * 0.7 + p300Deflection * 0.6 + Math.sin(2 * Math.PI * 10.0 * t) * 9.0;
    channelValues['Pz'] = pinkNoise + mains50 * 0.6 + p300Deflection * 1.1 + Math.sin(2 * Math.PI * 10.2 * t) * 11.0;
    channelValues['P4'] = pinkNoise + mains50 * 0.7 + p300Deflection * 0.6 + Math.sin(2 * Math.PI * 10.0 * t + 0.4) * 9.5;

    // Occipital Channels (O1, O2)
    channelValues['O1'] = pinkNoise + mains50 * 0.8 + alphaOccipital;
    channelValues['O2'] = pinkNoise + mains50 * 0.8 + alphaOccipital * 1.08 + (Math.random() - 0.5) * 3;

    // 2. EMG Channels (Surface Electromyography)
    // High-frequency interference pattern (50 - 450 Hz) modulated by contraction level
    const baseEmgNoise = (Math.random() - 0.5) * 12.0;
    const motorUnitFiring = (Math.random() - 0.5) * 220.0 * this.emgContraction;
    const emgSpikeTrain = Math.sin(2 * Math.PI * 135 * t) * 45.0 * this.emgContraction;

    channelValues['EMG1'] = baseEmgNoise + motorUnitFiring + emgSpikeTrain;
    channelValues['EMG2'] = baseEmgNoise * 0.9 + ((Math.random() - 0.5) * 180.0 * (this.emgContraction * 0.8));
    channelValues['EMG3'] = baseEmgNoise * 1.1 + ((Math.random() - 0.5) * 160.0 * (this.emgContraction * 0.6));
    channelValues['EMG4'] = baseEmgNoise + ((Math.random() - 0.5) * 140.0 * (this.emgContraction * 0.5));

    return {
      timestampMs: Math.floor(t * 1000),
      channelValues,
      event: newEvent,
    };
  }
}
