/**
 * Clinical Trials & Electrophysiology Research Cohorts
 * Standardized data models for translational neuroscience, BCI clinical studies,
 * and electrophysiological biomarker discovery.
 */

export interface ClinicalSubject {
  id: string;
  anonymousId: string;
  age: number;
  sex: 'M' | 'F' | 'Other';
  condition: string;
  cohortArm: 'Experimental (Active BCI)' | 'Sham Control' | 'Standard Care';
  status: 'Active' | 'Completed' | 'Screening';
  baselineScore: { metric: string; value: number; unit: string };
  currentScore: { metric: string; value: number; unit: string };
  recordedSessions: number;
  lastSessionDate: string;
  electrodeMontage: '10-20 Standard 12-Ch' | 'High-Density 64-Ch' | 'Surface EMG 4-Ch' | 'Hybrid EEG+EMG';
  notes: string;
}

export interface ClinicalTrialProtocol {
  id: string;
  code: string;
  title: string;
  phase: 'Phase I' | 'Phase II' | 'Observational' | 'Investigator-Initiated';
  primaryIndication: string;
  sponsor: string;
  irbApprovalNumber: string;
  targetEnrollment: number;
  currentEnrolled: number;
  primaryBiomarker: string;
  paradigm: 'Motor Imagery (Sensorimotor Rhythms)' | 'Event-Related Potential (P300)' | 'Continuous Sleep & Spike Discharge' | 'Neuromuscular Fatigue & MUAP';
  samplingRateHz: number;
  frequencyRange: string;
  subjects: ClinicalSubject[];
  description: string;
}

export interface AnnotationItem {
  id: string;
  timestampSec: number;
  durationSec: number;
  label: string;
  category: 'clinical_event' | 'artifact' | 'stimulus' | 'investigator_note';
  channelId?: string;
  investigator: string;
  comments: string;
}

export const CLINICAL_TRIALS: ClinicalTrialProtocol[] = [
  {
    id: 'trial-bci-motor-02',
    code: 'RESTORE-BCI-02',
    title: 'Closed-Loop Non-Invasive Sensorimotor Neuroprosthetic Re-Training for Severe Motor Paralysis',
    phase: 'Phase II',
    primaryIndication: 'Cervical Spinal Cord Injury & Amyotrophic Lateral Sclerosis (ALS)',
    sponsor: 'BrainGate & NeuroFlux Translational Consortium',
    irbApprovalNumber: 'IRB-2025-NEURO-8819',
    targetEnrollment: 24,
    currentEnrolled: 18,
    primaryBiomarker: 'Sensorimotor Rhythm Contralateral Mu (10Hz) & Beta (20Hz) Desynchronization (ERD) Index',
    paradigm: 'Motor Imagery (Sensorimotor Rhythms)',
    samplingRateHz: 500,
    frequencyRange: '0.5 Hz - 45 Hz',
    description: 'Investigating real-time decoding of intended hand opening/closing to drive external robotic orthosis via event-related desynchronization across primary motor strip C3/C4.',
    subjects: [
      {
        id: 'sub-01',
        anonymousId: 'SUB-M01-ALS',
        age: 54,
        sex: 'M',
        condition: 'ALS (Bulbar-sparing)',
        cohortArm: 'Experimental (Active BCI)',
        status: 'Active',
        baselineScore: { metric: 'ALSFRS-R Upper Limb', value: 4, unit: '/12' },
        currentScore: { metric: 'ALSFRS-R Upper Limb', value: 7, unit: '/12' },
        recordedSessions: 14,
        lastSessionDate: '2026-09-24',
        electrodeMontage: 'Hybrid EEG+EMG',
        notes: 'High classification fidelity (>91%) on right grasp motor imagery. Contralateral C3 mu desynchronization clear at 10.2 Hz.',
      },
      {
        id: 'sub-02',
        anonymousId: 'SUB-M02-SCI',
        age: 38,
        sex: 'F',
        condition: 'C5-C6 Incomplete Tetraplegia',
        cohortArm: 'Experimental (Active BCI)',
        status: 'Active',
        baselineScore: { metric: 'Fugl-Meyer Upper Extremity', value: 18, unit: '/66' },
        currentScore: { metric: 'Fugl-Meyer Upper Extremity', value: 29, unit: '/66' },
        recordedSessions: 22,
        lastSessionDate: '2026-09-27',
        electrodeMontage: 'Hybrid EEG+EMG',
        notes: 'Demonstrated progressive recruitment of motor units on EMG channel 1 (Biceps) alongside C3 rhythm training.',
      },
      {
        id: 'sub-03',
        anonymousId: 'SUB-M03-ALS',
        age: 62,
        sex: 'M',
        condition: 'ALS (Limb-onset)',
        cohortArm: 'Sham Control',
        status: 'Active',
        baselineScore: { metric: 'ALSFRS-R Upper Limb', value: 5, unit: '/12' },
        currentScore: { metric: 'ALSFRS-R Upper Limb', value: 5, unit: '/12' },
        recordedSessions: 12,
        lastSessionDate: '2026-09-20',
        electrodeMontage: '10-20 Standard 12-Ch',
        notes: 'Assigned to sham neurofeedback cohort arm for 8-week blinded validation block.',
      },
      {
        id: 'sub-04',
        anonymousId: 'SUB-M04-SCI',
        age: 44,
        sex: 'M',
        condition: 'C6 Complete Tetraplegia',
        cohortArm: 'Experimental (Active BCI)',
        status: 'Completed',
        baselineScore: { metric: 'Fugl-Meyer Upper Extremity', value: 12, unit: '/66' },
        currentScore: { metric: 'Fugl-Meyer Upper Extremity', value: 24, unit: '/66' },
        recordedSessions: 32,
        lastSessionDate: '2026-09-15',
        electrodeMontage: 'Hybrid EEG+EMG',
        notes: 'Protocol primary endpoint reached with significant neural prosthetic grasping efficiency improvement.',
      },
    ],
  },
  {
    id: 'trial-epilepsy-spike-01',
    code: 'NEURO-VIGIL-01',
    title: 'Continuous High-Frequency Electrophysiology for Automated Focal Spike & Seizure Precursor Detection',
    phase: 'Observational',
    primaryIndication: 'Pediatric & Adult Drug-Resistant Focal Epilepsy',
    sponsor: 'Academic Medical Center Epilepsy Monitoring Unit',
    irbApprovalNumber: 'IRB-2025-EPI-4491',
    targetEnrollment: 50,
    currentEnrolled: 39,
    primaryBiomarker: 'Interictal Epileptiform Discharge (IED) Rate & High-Frequency Oscillation (80-250 Hz Ripple) Density',
    paradigm: 'Continuous Sleep & Spike Discharge',
    samplingRateHz: 1000,
    frequencyRange: '0.1 Hz - 100 Hz',
    description: 'Longitudinal automated detection of interictal sharp waves and paroxysmal fast activity during transition into non-REM stage N2/N3 sleep.',
    subjects: [
      {
        id: 'sub-e01',
        anonymousId: 'SUB-E01-TLE',
        age: 26,
        sex: 'F',
        condition: 'Mesial Temporal Lobe Epilepsy',
        cohortArm: 'Experimental (Active BCI)',
        status: 'Active',
        baselineScore: { metric: 'Monthly Seizure Frequency', value: 6.2, unit: 'events/mo' },
        currentScore: { metric: 'Monthly Seizure Frequency', value: 2.1, unit: 'events/mo' },
        recordedSessions: 8,
        lastSessionDate: '2026-09-28',
        electrodeMontage: '10-20 Standard 12-Ch',
        notes: 'Prominent phase-amplitude coupling between theta (4-7Hz) and ripple bursts over temporal derivations.',
      },
      {
        id: 'sub-e02',
        anonymousId: 'SUB-E02-FCD',
        age: 19,
        sex: 'M',
        condition: 'Focal Cortical Dysplasia Type II',
        cohortArm: 'Experimental (Active BCI)',
        status: 'Active',
        baselineScore: { metric: 'Monthly Seizure Frequency', value: 11.0, unit: 'events/mo' },
        currentScore: { metric: 'Monthly Seizure Frequency', value: 4.5, unit: 'events/mo' },
        recordedSessions: 16,
        lastSessionDate: '2026-09-26',
        electrodeMontage: '10-20 Standard 12-Ch',
        notes: 'Pre-ictal spike clusters detected ~14 minutes prior to clinical electrographic onset.',
      },
    ],
  },
  {
    id: 'trial-myofit-emg-03',
    code: 'MYOFIT-EMG-03',
    title: 'High-Density Surface Electromyography Neuromuscular Fatigue Decay in Spinal Muscular Atrophy',
    phase: 'Investigator-Initiated',
    primaryIndication: 'Spinal Muscular Atrophy (SMA Type 3) & Charcot-Marie-Tooth (CMT)',
    sponsor: 'Neuromuscular Biomechanics Institute',
    irbApprovalNumber: 'IRB-2026-NMD-309',
    targetEnrollment: 30,
    currentEnrolled: 22,
    primaryBiomarker: 'Median Power Frequency (MDF) Downshift & Motor Unit Action Potential (MUAP) Recruitment Amplitude',
    paradigm: 'Neuromuscular Fatigue & MUAP',
    samplingRateHz: 2048,
    frequencyRange: '10 Hz - 450 Hz',
    description: 'Assessing myoelectric spectral compression under 40% maximal voluntary contraction (MVC) during sustained isometric forearm flexion.',
    subjects: [
      {
        id: 'sub-emg01',
        anonymousId: 'SUB-N01-SMA',
        age: 33,
        sex: 'F',
        condition: 'SMA Type 3 (Nusinersen maintenance)',
        cohortArm: 'Experimental (Active BCI)',
        status: 'Active',
        baselineScore: { metric: 'Max Voluntary Contraction (MVC)', value: 42, unit: 'N' },
        currentScore: { metric: 'Max Voluntary Contraction (MVC)', value: 58, unit: 'N' },
        recordedSessions: 19,
        lastSessionDate: '2026-09-22',
        electrodeMontage: 'Surface EMG 4-Ch',
        notes: 'Fatigue index shows stabilization; median frequency shift slowed by 32% compared to pre-treatment baseline.',
      },
    ],
  },
  {
    id: 'trial-p300-cognition-04',
    code: 'COG-P300-04',
    title: 'Novelty P300 Auditory Oddball Latency and Amplitude as Biomarker for Early Amnestic Mild Cognitive Impairment',
    phase: 'Phase I',
    primaryIndication: 'Amnestic Mild Cognitive Impairment (aMCI) / Pre-Symptomatic Alzheimer’s Disease',
    sponsor: 'National Neurocognitive Diagnostics Group',
    irbApprovalNumber: 'IRB-2025-COG-7212',
    targetEnrollment: 60,
    currentEnrolled: 47,
    primaryBiomarker: 'P3b Parietal Peak Latency (ms) & Peak Amplitude (µV) under 1000Hz Oddball Paradigm',
    paradigm: 'Event-Related Potential (P300)',
    samplingRateHz: 500,
    frequencyRange: '0.1 Hz - 30 Hz',
    description: 'Quantifying microsecond latency shifts in the late positive complex at parietal electrode Pz during a two-tone auditory oddball sequence.',
    subjects: [
      {
        id: 'sub-c01',
        anonymousId: 'SUB-C01-MCI',
        age: 69,
        sex: 'M',
        condition: 'Amnestic MCI (CDR 0.5)',
        cohortArm: 'Experimental (Active BCI)',
        status: 'Active',
        baselineScore: { metric: 'MoCA Cognitive Score', value: 22, unit: '/30' },
        currentScore: { metric: 'MoCA Cognitive Score', value: 24, unit: '/30' },
        recordedSessions: 6,
        lastSessionDate: '2026-09-18',
        electrodeMontage: '10-20 Standard 12-Ch',
        notes: 'P3b peak delayed to 372ms (healthy age-matched normative is 315-330ms). Peak amplitude 11.4 µV.',
      },
    ],
  },
];

export const INITIAL_RECORDING_ANNOTATIONS: AnnotationItem[] = [
  {
    id: 'ann-01',
    timestampSec: 1.25,
    durationSec: 0.12,
    label: 'Target Oddball Tone S2 (1000 Hz)',
    category: 'stimulus',
    channelId: 'Pz',
    investigator: 'Dr. Elena Rostova',
    comments: 'Rare target stimulus presented; expected P300 elicitation at +320ms latency.',
  },
  {
    id: 'ann-02',
    timestampSec: 2.80,
    durationSec: 0.28,
    label: 'Ocular Blink (EOG Artifact)',
    category: 'artifact',
    channelId: 'Fp1',
    investigator: 'Dr. Elena Rostova',
    comments: 'High amplitude bilateral positive deflection on Fp1/Fp2 (>60 µV); marked for ICA rejection.',
  },
  {
    id: 'ann-03',
    timestampSec: 4.10,
    durationSec: 1.50,
    label: 'Motor Imagery Grasp Attempt (Right Hand)',
    category: 'clinical_event',
    channelId: 'C3',
    investigator: 'Dr. Marcus Vance',
    comments: 'Sensorimotor mu rhythm (10 Hz) suppression observed over contralateral C3.',
  },
  {
    id: 'ann-04',
    timestampSec: 6.90,
    durationSec: 0.40,
    label: 'Interictal Sharp Transient',
    category: 'clinical_event',
    channelId: 'F3',
    investigator: 'Dr. Marcus Vance',
    comments: 'Focal phase-reversal between F3 and C3 with subsequent slow wave component.',
  },
  {
    id: 'ann-05',
    timestampSec: 8.50,
    durationSec: 0.80,
    label: 'Temporalis Muscle Clench (EMG Spillover)',
    category: 'artifact',
    channelId: 'Fp2',
    investigator: 'Dr. Elena Rostova',
    comments: 'High frequency noise >40Hz; bandpass filter 0.5-45Hz suppresses artifact.',
  },
];
