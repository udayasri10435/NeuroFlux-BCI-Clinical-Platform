import React, { useState, useEffect, useRef, useMemo, useCallback } from 'react';
import {
  ChannelInfo,
  STANDARD_10_20_EEG_CHANNELS,
  STANDARD_EMG_CHANNELS,
  BiosignalGenerator,
  FilterConfig,
  MarkerEvent,
} from './services/dspEngine';
import {
  CLINICAL_TRIALS,
  INITIAL_RECORDING_ANNOTATIONS,
  AnnotationItem,
} from './data/clinicalTrials';
import { OscilloscopeCanvas } from './components/OscilloscopeCanvas';
import { ScalpTopomap } from './components/ScalpTopomap';
import { SpectralAnalyzer } from './components/SpectralAnalyzer';
import { BciWorkbench } from './components/BciWorkbench';
import { ClinicalTrialWorkspace } from './components/ClinicalTrialWorkspace';
import { AiNeuroAssistant } from './components/AiNeuroAssistant';
import {
  Activity,
  Play,
  Pause,
  Download,
  Upload,
  Brain,
  Sliders,
  Sparkles,
  Layers,
  FileSpreadsheet,
  Cpu,
  ShieldCheck,
  CheckCircle,
} from 'lucide-react';

export default function App() {
  // Navigation active tab
  const [activeNav, setActiveNav] = useState<
    'workbench' | 'spectral' | 'bci_decoder' | 'clinical_trials' | 'ai_investigator'
  >('workbench');

  // Combined channels (12 EEG + 4 EMG)
  const [channels] = useState<ChannelInfo[]>([
    ...STANDARD_10_20_EEG_CHANNELS,
    ...STANDARD_EMG_CHANNELS,
  ]);

  // Selected channel for spectral and topomap inspection
  const [selectedChannelId, setSelectedChannelId] = useState<string>('Pz');

  // Filter Configuration
  const [filterConfig, setFilterConfig] = useState<FilterConfig>({
    notch50Hz: true,
    notch60Hz: false,
    highPassCutoff: 0.5,
    lowPassCutoff: 45,
    enableBandpass: true,
    detrend: true,
    emgEnvelope: false,
  });

  // Display Parameters
  const [gainMicroVolts, setGainMicroVolts] = useState<number>(50);
  const [timeWindowSec, setTimeWindowSec] = useState<number>(5);
  const [showFiltered, setShowFiltered] = useState<boolean>(true);
  const [activeLobeFilter, setActiveLobeFilter] = useState<string>('ALL');

  // Signal Generator & Playback State
  const [isPlaying, setIsPlaying] = useState<boolean>(true);
  const [motorState, setMotorState] = useState<'none' | 'left' | 'right'>('none');
  const [emgContraction, setEmgContraction] = useState<number>(0.2);

  // Telemetry Buffers
  const [timeStamps, setTimeStamps] = useState<number[]>([]);
  const [signalBuffer, setSignalBuffer] = useState<Record<string, number[]>>({});
  const [events, setEvents] = useState<MarkerEvent[]>([]);

  // Clinical Trials State
  const [selectedTrialId, setSelectedTrialId] = useState<string>('trial-bci-motor-02');
  const [annotations, setAnnotations] = useState<AnnotationItem[]>(INITIAL_RECORDING_ANNOTATIONS);
  const [notification, setNotification] = useState<string | null>(null);

  // Generator reference
  const generatorRef = useRef<BiosignalGenerator | null>(null);
  if (!generatorRef.current) {
    generatorRef.current = new BiosignalGenerator(250);
  }

  // Sync generator settings
  useEffect(() => {
    if (generatorRef.current) {
      generatorRef.current.setMotorImagery(motorState);
      generatorRef.current.setEmgContraction(emgContraction);
    }
  }, [motorState, emgContraction]);

  // Notification helper
  const showToast = (msg: string) => {
    setNotification(msg);
    setTimeout(() => setNotification(null), 3200);
  };

  // Populate initial buffer so charts and oscilloscope have data on startup
  useEffect(() => {
    const initialTimestamps: number[] = [];
    const initialSignals: Record<string, number[]> = {};
    channels.forEach((ch) => {
      initialSignals[ch.id] = [];
    });

    const gen = generatorRef.current;
    if (gen) {
      // Simulate 5 seconds of pre-buffered data (1250 samples at 250 Hz)
      for (let i = 0; i < 1250; i++) {
        const step = gen.step(1 / 250);
        initialTimestamps.push(step.timestampMs);
        for (const chId in step.channelValues) {
          if (initialSignals[chId]) {
            initialSignals[chId].push(step.channelValues[chId]);
          }
        }
      }
      setTimeStamps(initialTimestamps);
      setSignalBuffer(initialSignals);
    }
  }, [channels]);

  // Real-time acquisition loop
  useEffect(() => {
    if (!isPlaying) return;

    const interval = setInterval(() => {
      const gen = generatorRef.current;
      if (!gen) return;

      // Batch 10 samples per tick (~40ms interval = 250 samples/sec)
      const newTimes: number[] = [];
      const newSamples: Record<string, number[]> = {};
      channels.forEach((c) => {
        newSamples[c.id] = [];
      });

      let latestEv: MarkerEvent | undefined;

      for (let s = 0; s < 10; s++) {
        const step = gen.step(1 / 250);
        newTimes.push(step.timestampMs);
        if (step.event) {
          latestEv = step.event;
        }
        for (const chId in step.channelValues) {
          if (newSamples[chId]) {
            newSamples[chId].push(step.channelValues[chId]);
          }
        }
      }

      // Max buffer size: 2500 samples (10 seconds history)
      const MAX_SAMPLES = 2500;

      setTimeStamps((prev) => {
        const combined = [...prev, ...newTimes];
        return combined.length > MAX_SAMPLES ? combined.slice(combined.length - MAX_SAMPLES) : combined;
      });

      setSignalBuffer((prev) => {
        const updated: Record<string, number[]> = {};
        for (const chId in prev) {
          const added = newSamples[chId] || [];
          const combined = [...(prev[chId] || []), ...added];
          updated[chId] = combined.length > MAX_SAMPLES ? combined.slice(combined.length - MAX_SAMPLES) : combined;
        }
        return updated;
      });

      if (latestEv) {
        setEvents((prev) => [...prev.slice(-30), latestEv!]);
      }
    }, 40);

    return () => clearInterval(interval);
  }, [isPlaying, channels]);

  // Handle reset
  const handleReset = () => {
    setTimeStamps([]);
    const cleared: Record<string, number[]> = {};
    channels.forEach((ch) => {
      cleared[ch.id] = [];
    });
    setSignalBuffer(cleared);
    setEvents([]);
    showToast('Telemetry buffer cleared');
  };

  // Add annotation from canvas click
  const handleCanvasAddAnnotation = (timestampSec: number, channelId?: string) => {
    const newAnn: AnnotationItem = {
      id: `ann-${Date.now()}`,
      timestampSec,
      durationSec: 0.2,
      label: 'Investigator Event Marker',
      category: 'investigator_note',
      channelId: channelId || selectedChannelId,
      investigator: 'Dr. Principal Investigator',
      comments: `Flagged marker at ${timestampSec.toFixed(2)}s on ${channelId || selectedChannelId}`,
    };
    setAnnotations((prev) => [...prev, newAnn]);
    showToast(`Annotation pinned at ${timestampSec.toFixed(2)}s`);
  };

  const handleAddAnnotation = (annotationData: Omit<AnnotationItem, 'id'>) => {
    const newAnn: AnnotationItem = {
      ...annotationData,
      id: `ann-${Date.now()}`,
    };
    setAnnotations((prev) => [...prev, newAnn]);
    showToast(`Saved annotation: ${annotationData.label}`);
  };

  const handleDeleteAnnotation = (id: string) => {
    setAnnotations((prev) => prev.filter((a) => a.id !== id));
    showToast('Annotation removed');
  };

  // Export dataset as CSV
  const handleExportCsv = () => {
    if (timeStamps.length === 0) {
      showToast('No signal data to export');
      return;
    }

    const headers = ['Timestamp_ms', ...channels.map((c) => `${c.name}_uV`)];
    const rows = [headers.join(',')];

    for (let i = 0; i < timeStamps.length; i += 2) {
      const row = [timeStamps[i].toString()];
      for (const ch of channels) {
        const val = signalBuffer[ch.id]?.[i] ?? 0;
        row.push(val.toFixed(2));
      }
      rows.push(row.join(','));
    }

    const csvContent = 'data:text/csv;charset=utf-8,' + encodeURIComponent(rows.join('\n'));
    const link = document.createElement('a');
    link.setAttribute('href', csvContent);
    link.setAttribute('download', `NeuroFlux_Session_${new Date().toISOString().slice(0, 10)}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    showToast('Exported multi-channel dataset (.CSV)');
  };

  const handleImportData = (fileName: string, rowCount: number) => {
    showToast(`Imported ${fileName} (${rowCount} synthetic epochs ingested)`);
  };

  const currentTrial = useMemo(() => {
    return CLINICAL_TRIALS.find((t) => t.id === selectedTrialId) || CLINICAL_TRIALS[0];
  }, [selectedTrialId]);

  return (
    <div className="flex flex-col min-h-screen bg-[#090C15] text-[#E2E8F0]">
      {/* 
        TOP BAR CONTRACT:
        Zone 1: Single text element wordmark
        Zone 2: 4-6 clean text navigation links with active state
        Zone 3: 1-2 primary actions
      */}
      <header className="flex items-center justify-between px-6 py-3.5 bg-[#090C15] border-b border-slate-800 shrink-0 sticky top-0 z-40">
        {/* Zone 1: Single text element wordmark */}
        <div className="flex items-center gap-2">
          <Activity className="w-5 h-5 text-cyan-400 shrink-0" />
          <span className="text-base font-bold tracking-tight text-slate-100 font-tech">
            NeuroFlux BCI
          </span>
        </div>

        {/* Zone 2: 4-6 clean text navigation links */}
        <nav className="hidden md:flex items-center gap-8 text-xs font-medium">
          <button
            onClick={() => setActiveNav('workbench')}
            className={`transition-colors py-1 ${
              activeNav === 'workbench'
                ? 'text-cyan-400 border-b-2 border-cyan-400 font-semibold'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Oscilloscope
          </button>
          <button
            onClick={() => setActiveNav('spectral')}
            className={`transition-colors py-1 ${
              activeNav === 'spectral'
                ? 'text-cyan-400 border-b-2 border-cyan-400 font-semibold'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Spectral & Topography
          </button>
          <button
            onClick={() => setActiveNav('bci_decoder')}
            className={`transition-colors py-1 ${
              activeNav === 'bci_decoder'
                ? 'text-cyan-400 border-b-2 border-cyan-400 font-semibold'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            BCI Decoder
          </button>
          <button
            onClick={() => setActiveNav('clinical_trials')}
            className={`transition-colors py-1 ${
              activeNav === 'clinical_trials'
                ? 'text-cyan-400 border-b-2 border-cyan-400 font-semibold'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Clinical Trials
          </button>
          <button
            onClick={() => setActiveNav('ai_investigator')}
            className={`transition-colors py-1 flex items-center gap-1.5 ${
              activeNav === 'ai_investigator'
                ? 'text-cyan-400 border-b-2 border-cyan-400 font-semibold'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Sparkles className="w-3.5 h-3.5 text-cyan-400" />
            <span>AI Investigator</span>
          </button>
        </nav>

        {/* Zone 3: 1-2 primary actions */}
        <div className="flex items-center gap-3">
          <button
            onClick={() => setIsPlaying(!isPlaying)}
            className={`px-3.5 py-1.5 text-xs font-semibold rounded transition-colors flex items-center gap-1.5 whitespace-nowrap ${
              isPlaying
                ? 'bg-amber-500/10 text-amber-400 border border-amber-500/30 hover:bg-amber-500/20'
                : 'bg-emerald-500 text-slate-950 hover:bg-emerald-400'
            }`}
          >
            {isPlaying ? <Pause className="w-3.5 h-3.5" /> : <Play className="w-3.5 h-3.5" />}
            <span>{isPlaying ? 'Pause Acquisition' : 'Start Stream'}</span>
          </button>

          <button
            onClick={handleExportCsv}
            className="hidden sm:flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-slate-300 bg-slate-900 border border-slate-700 hover:bg-slate-800 rounded transition-colors whitespace-nowrap"
          >
            <Download className="w-3.5 h-3.5 text-slate-400" />
            <span>Export CSV</span>
          </button>
        </div>
      </header>

      {/* Persistent Scientific Telemetry Sub-Ribbon (Zero-Pill Metadata) */}
      <div className="flex flex-wrap items-center justify-between gap-3 px-6 py-2 bg-[#0B0F1A] border-b border-slate-800/80 text-xs">
        <div className="flex items-center gap-3 text-slate-400 font-mono-data">
          <span className="text-slate-200 font-semibold">{currentTrial.code}</span>
          <span aria-hidden="true">·</span>
          <span>{currentTrial.paradigm}</span>
          <span aria-hidden="true">·</span>
          <span className="text-emerald-400">IRB APPROVED</span>
          <span aria-hidden="true">·</span>
          <span>{currentTrial.currentEnrolled} / {currentTrial.targetEnrollment} Subjects</span>
        </div>

        <div className="flex items-center gap-4 text-slate-400 text-xs font-mono-data">
          <span>ADC: 24-bit Sigma-Delta</span>
          <span aria-hidden="true">·</span>
          <span>Fs: 250 Hz</span>
          <span aria-hidden="true">·</span>
          <span className="text-cyan-400">Notch: {filterConfig.notch50Hz ? '50Hz ON' : 'OFF'}</span>
          <span aria-hidden="true">·</span>
          <span>16 Active Electrodes</span>
        </div>
      </div>

      {/* Main Workspace Content Area */}
      <main className="flex-1 p-4 lg:p-6 overflow-hidden">
        {/* View 1: Main Integrated Workbench (Oscilloscope + Side Panels) */}
        {activeNav === 'workbench' && (
          <div className="grid grid-cols-1 xl:grid-cols-3 gap-4 h-[calc(100vh-140px)]">
            {/* Left 2 Cols: Full Oscilloscope Canvas */}
            <div className="xl:col-span-2 h-full min-h-[500px]">
              <OscilloscopeCanvas
                channels={channels}
                signalBuffer={signalBuffer}
                timeStamps={timeStamps}
                filterConfig={filterConfig}
                events={events}
                annotations={annotations}
                isPlaying={isPlaying}
                onTogglePlay={() => setIsPlaying(!isPlaying)}
                onReset={handleReset}
                onAddAnnotation={handleCanvasAddAnnotation}
                gainMicroVolts={gainMicroVolts}
                setGainMicroVolts={setGainMicroVolts}
                timeWindowSec={timeWindowSec}
                setTimeWindowSec={setTimeWindowSec}
                showFiltered={showFiltered}
                setShowFiltered={setShowFiltered}
                samplingRate={250}
                activeLobeFilter={activeLobeFilter}
                setActiveLobeFilter={setActiveLobeFilter}
              />
            </div>

            {/* Right Col: Topography + Fast Spectral Gauge */}
            <div className="h-full flex flex-col gap-4 overflow-y-auto">
              <div className="h-[360px] shrink-0">
                <ScalpTopomap
                  channels={channels}
                  signalBuffer={signalBuffer}
                  selectedChannelId={selectedChannelId}
                  onSelectChannel={setSelectedChannelId}
                />
              </div>

              <div className="flex-1 min-h-[300px]">
                <SpectralAnalyzer
                  channels={channels}
                  signalBuffer={signalBuffer}
                  selectedChannelId={selectedChannelId}
                  onSelectChannel={setSelectedChannelId}
                />
              </div>
            </div>
          </div>
        )}

        {/* View 2: High-Density Spectral Analysis & 2D Topography Map */}
        {activeNav === 'spectral' && (
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 h-[calc(100vh-140px)]">
            <div className="h-full">
              <ScalpTopomap
                channels={channels}
                signalBuffer={signalBuffer}
                selectedChannelId={selectedChannelId}
                onSelectChannel={setSelectedChannelId}
              />
            </div>
            <div className="h-full">
              <SpectralAnalyzer
                channels={channels}
                signalBuffer={signalBuffer}
                selectedChannelId={selectedChannelId}
                onSelectChannel={setSelectedChannelId}
              />
            </div>
          </div>
        )}

        {/* View 3: BCI Decoder & Signal Processing Workbench */}
        {activeNav === 'bci_decoder' && (
          <div className="h-[calc(100vh-140px)]">
            <BciWorkbench
              filterConfig={filterConfig}
              onUpdateFilterConfig={setFilterConfig}
              channels={channels}
              motorState={motorState}
              onSetMotorState={setMotorState}
              onTriggerP300={(isOdd) => {
                if (generatorRef.current) {
                  generatorRef.current.triggerP300Stimulus(isOdd);
                  showToast(isOdd ? 'Dispatched Target S2 (1000Hz)' : 'Dispatched Tone S1');
                }
              }}
              emgContraction={emgContraction}
              onSetEmgContraction={setEmgContraction}
              signalBuffer={signalBuffer}
            />
          </div>
        )}

        {/* View 4: Clinical Trial Protocols & Cohort Management */}
        {activeNav === 'clinical_trials' && (
          <div className="h-[calc(100vh-140px)]">
            <ClinicalTrialWorkspace
              trials={CLINICAL_TRIALS}
              selectedTrialId={selectedTrialId}
              onSelectTrial={setSelectedTrialId}
              annotations={annotations}
              onAddAnnotation={handleAddAnnotation}
              onDeleteAnnotation={handleDeleteAnnotation}
              onExportCsv={handleExportCsv}
              onImportData={handleImportData}
            />
          </div>
        )}

        {/* View 5: AI Neurophysiology Assistant */}
        {activeNav === 'ai_investigator' && (
          <div className="h-[calc(100vh-140px)]">
            <AiNeuroAssistant
              currentTrial={currentTrial}
              channels={channels}
              signalBuffer={signalBuffer}
              filterConfig={filterConfig}
              annotations={annotations}
              motorState={motorState}
              emgContraction={emgContraction}
            />
          </div>
        )}
      </main>

      {/* Feedback Toast Notification */}
      {notification && (
        <div className="fixed bottom-4 right-4 z-50 flex items-center gap-2 bg-[#0E1322] border border-cyan-500/50 text-slate-200 px-4 py-2.5 rounded shadow-xl text-xs font-mono-data animate-fade-in">
          <CheckCircle className="w-4 h-4 text-cyan-400" />
          <span>{notification}</span>
        </div>
      )}
    </div>
  );
}
