import React, { useState } from 'react';
import { ClinicalTrialProtocol, ClinicalSubject, AnnotationItem } from '../data/clinicalTrials';
import { Users, FileText, Download, Upload, Plus, Trash2, Calendar, ClipboardCheck, Tag, Shield } from 'lucide-react';

interface ClinicalTrialWorkspaceProps {
  trials: ClinicalTrialProtocol[];
  selectedTrialId: string;
  onSelectTrial: (id: string) => void;
  annotations: AnnotationItem[];
  onAddAnnotation: (annotation: Omit<AnnotationItem, 'id'>) => void;
  onDeleteAnnotation: (id: string) => void;
  onExportCsv: () => void;
  onImportData: (fileName: string, rowCount: number) => void;
}

export const ClinicalTrialWorkspace: React.FC<ClinicalTrialWorkspaceProps> = ({
  trials,
  selectedTrialId,
  onSelectTrial,
  annotations,
  onAddAnnotation,
  onDeleteAnnotation,
  onExportCsv,
  onImportData,
}) => {
  const [activeTab, setActiveTab] = useState<'cohort' | 'protocol' | 'annotations' | 'import_export'>('cohort');
  const [showAddModal, setShowAddModal] = useState(false);
  const [newLabel, setNewLabel] = useState('');
  const [newCategory, setNewCategory] = useState<'clinical_event' | 'artifact' | 'stimulus' | 'investigator_note'>('clinical_event');
  const [newTimestamp, setNewTimestamp] = useState('3.50');
  const [newComments, setNewComments] = useState('');
  const [newInvestigator, setNewInvestigator] = useState('Dr. Principal Investigator');

  const currentTrial = trials.find((t) => t.id === selectedTrialId) || trials[0];

  const handleCreateAnnotation = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newLabel) return;
    onAddAnnotation({
      timestampSec: parseFloat(newTimestamp) || 1.0,
      durationSec: 0.25,
      label: newLabel,
      category: newCategory,
      investigator: newInvestigator,
      comments: newComments || 'Investigator timestamp marker',
    });
    setNewLabel('');
    setNewComments('');
    setShowAddModal(false);
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    onImportData(file.name, 1500);
  };

  return (
    <div className="flex flex-col h-full bg-[#0E1322] border border-slate-800 rounded-lg p-4">
      {/* Header and Trial Selector */}
      <div className="flex flex-wrap items-center justify-between gap-3 pb-3 border-b border-slate-800">
        <div className="flex items-center gap-3">
          <ClipboardCheck className="w-5 h-5 text-cyan-400" />
          <div>
            <div className="flex items-center gap-2">
              <h3 className="text-sm font-semibold text-slate-100">{currentTrial.code}</h3>
              <span className="text-xs text-slate-400 font-mono-data">· {currentTrial.phase}</span>
              <span className="text-xs text-cyan-400 font-mono-data">· IRB: {currentTrial.irbApprovalNumber}</span>
            </div>
            <p className="text-xs text-slate-400 max-w-xl truncate mt-0.5">{currentTrial.title}</p>
          </div>
        </div>

        {/* Protocol Switcher Dropdown */}
        <div className="flex items-center gap-2">
          <span className="text-xs text-slate-400 font-mono-data">PROTOCOL:</span>
          <select
            value={selectedTrialId}
            onChange={(e) => onSelectTrial(e.target.value)}
            className="bg-slate-900 border border-slate-700 text-slate-200 text-xs px-2.5 py-1.5 rounded font-mono-data focus:outline-none focus:border-cyan-500"
          >
            {trials.map((t) => (
              <option key={t.id} value={t.id}>
                {t.code} - {t.primaryIndication.slice(0, 36)}...
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* Navigation Sub-Tabs */}
      <div className="flex items-center justify-between my-3">
        <div className="flex items-center gap-1 bg-slate-900 border border-slate-800 p-0.5 rounded text-xs">
          <button
            onClick={() => setActiveTab('cohort')}
            className={`px-3 py-1 font-medium rounded transition-colors whitespace-nowrap ${
              activeTab === 'cohort' ? 'bg-cyan-500/20 text-cyan-300 font-semibold' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Subject Cohort ({currentTrial.subjects.length})
          </button>
          <button
            onClick={() => setActiveTab('protocol')}
            className={`px-3 py-1 font-medium rounded transition-colors whitespace-nowrap ${
              activeTab === 'protocol' ? 'bg-cyan-500/20 text-cyan-300 font-semibold' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Trial Biomarkers & Design
          </button>
          <button
            onClick={() => setActiveTab('annotations')}
            className={`px-3 py-1 font-medium rounded transition-colors whitespace-nowrap ${
              activeTab === 'annotations' ? 'bg-cyan-500/20 text-cyan-300 font-semibold' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Clinical Annotations ({annotations.length})
          </button>
          <button
            onClick={() => setActiveTab('import_export')}
            className={`px-3 py-1 font-medium rounded transition-colors whitespace-nowrap ${
              activeTab === 'import_export' ? 'bg-cyan-500/20 text-cyan-300 font-semibold' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            EDF / CSV Ingestion
          </button>
        </div>

        {activeTab === 'annotations' && (
          <button
            onClick={() => setShowAddModal(true)}
            className="flex items-center gap-1.5 px-3 py-1 text-xs font-semibold bg-cyan-500 hover:bg-cyan-400 text-slate-950 rounded transition-colors"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Add Annotation</span>
          </button>
        )}
      </div>

      {/* Tab 1: Subject Cohort Table */}
      {activeTab === 'cohort' && (
        <div className="flex-1 overflow-x-auto">
          <table className="w-full text-left text-xs border border-slate-800 rounded">
            <thead className="bg-[#090C15] text-slate-400 font-mono-data border-b border-slate-800 uppercase text-[10px]">
              <tr>
                <th className="py-2.5 px-3">Subject ID</th>
                <th className="py-2.5 px-3">Age/Sex</th>
                <th className="py-2.5 px-3">Condition</th>
                <th className="py-2.5 px-3">Cohort Arm</th>
                <th className="py-2.5 px-3">Baseline Endpoint</th>
                <th className="py-2.5 px-3">Current Endpoint</th>
                <th className="py-2.5 px-3">Δ Change</th>
                <th className="py-2.5 px-3">Sessions</th>
                <th className="py-2.5 px-3">Electrode Montage</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/80">
              {currentTrial.subjects.map((sub) => {
                const delta = sub.currentScore.value - sub.baselineScore.value;
                const isImprovement = delta > 0;
                return (
                  <tr key={sub.id} className="hover:bg-slate-900/40 transition-colors">
                    <td className="py-2.5 px-3 font-mono-data font-semibold text-slate-100">
                      {sub.anonymousId}
                    </td>
                    <td className="py-2.5 px-3 text-slate-300 font-mono-data">
                      {sub.age}y / {sub.sex}
                    </td>
                    <td className="py-2.5 px-3 text-slate-300 max-w-[180px] truncate" title={sub.condition}>
                      {sub.condition}
                    </td>
                    <td className="py-2.5 px-3 font-mono-data text-slate-300">
                      {sub.cohortArm}
                    </td>
                    <td className="py-2.5 px-3 font-mono-data text-slate-400">
                      {sub.baselineScore.value} {sub.baselineScore.unit}
                    </td>
                    <td className="py-2.5 px-3 font-mono-data font-bold text-slate-100">
                      {sub.currentScore.value} {sub.currentScore.unit}
                    </td>
                    <td className="py-2.5 px-3 font-mono-data">
                      <span className={isImprovement ? 'text-emerald-400 font-semibold' : 'text-slate-400'}>
                        {delta > 0 ? `+${delta}` : delta} {sub.currentScore.unit}
                      </span>
                    </td>
                    <td className="py-2.5 px-3 font-mono-data text-slate-300">
                      {sub.recordedSessions} runs
                    </td>
                    <td className="py-2.5 px-3 text-slate-400 font-mono-data">
                      {sub.electrodeMontage}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      )}

      {/* Tab 2: Trial Protocol & Biomarkers */}
      {activeTab === 'protocol' && (
        <div className="flex-1 space-y-3 overflow-y-auto">
          <div className="bg-[#090C15] border border-slate-800 p-3 rounded">
            <h4 className="text-xs font-semibold text-slate-200 uppercase font-mono-data mb-1">
              PROTOCOL SCIENTIFIC SPECIFICATION
            </h4>
            <p className="text-xs text-slate-300 leading-relaxed">{currentTrial.description}</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            <div className="bg-[#090C15] border border-slate-800 p-3 rounded space-y-2">
              <span className="text-[11px] font-mono-data text-slate-400 uppercase">PRIMARY TRANSLATIONAL BIOMARKER</span>
              <p className="text-xs font-semibold text-cyan-300">{currentTrial.primaryBiomarker}</p>
              <div className="text-[11px] text-slate-400">
                Sampling Rate: {currentTrial.samplingRateHz} Hz · Passband: {currentTrial.frequencyRange}
              </div>
            </div>

            <div className="bg-[#090C15] border border-slate-800 p-3 rounded space-y-2">
              <span className="text-[11px] font-mono-data text-slate-400 uppercase">ENROLLMENT & GOVERNANCE</span>
              <div className="flex items-baseline gap-2">
                <span className="text-2xl font-bold font-mono-data text-slate-100">{currentTrial.currentEnrolled}</span>
                <span className="text-xs font-mono-data text-slate-400">/ {currentTrial.targetEnrollment} Target Enrolled</span>
              </div>
              <div className="w-full bg-slate-900 h-2 rounded overflow-hidden">
                <div
                  className="h-full bg-cyan-500"
                  style={{ width: `${(currentTrial.currentEnrolled / currentTrial.targetEnrollment) * 100}%` }}
                />
              </div>
              <div className="text-[11px] text-slate-400">
                Sponsor: {currentTrial.sponsor}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Tab 3: Clinical Annotations */}
      {activeTab === 'annotations' && (
        <div className="flex-1 overflow-y-auto space-y-2">
          {annotations.length === 0 ? (
            <div className="text-center py-8 text-xs text-slate-500">
              No clinical annotations in current recording. Click "Add Annotation" to create an investigator mark.
            </div>
          ) : (
            annotations.map((ann) => {
              const categoryColor =
                ann.category === 'clinical_event'
                  ? 'text-pink-400'
                  : ann.category === 'artifact'
                  ? 'text-rose-400'
                  : 'text-cyan-400';

              return (
                <div
                  key={ann.id}
                  className="flex items-start justify-between bg-[#090C15] border border-slate-800 p-2.5 rounded text-xs hover:border-slate-700 transition-colors"
                >
                  <div className="space-y-1">
                    <div className="flex items-center gap-2">
                      <span className="font-mono-data font-bold text-slate-200">
                        {ann.timestampSec.toFixed(2)}s
                      </span>
                      <span aria-hidden="true" className="text-slate-600">·</span>
                      <span className={`font-semibold ${categoryColor}`}>{ann.label}</span>
                      {ann.channelId && (
                        <>
                          <span aria-hidden="true" className="text-slate-600">·</span>
                          <span className="text-slate-400 font-mono-data">Ch: {ann.channelId}</span>
                        </>
                      )}
                    </div>
                    <p className="text-slate-400 text-[11px]">{ann.comments}</p>
                    <div className="text-[10px] text-slate-500 font-mono-data">
                      Logged by {ann.investigator}
                    </div>
                  </div>

                  <button
                    onClick={() => onDeleteAnnotation(ann.id)}
                    className="p-1 text-slate-500 hover:text-rose-400 transition-colors"
                    title="Delete annotation"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              );
            })
          )}
        </div>
      )}

      {/* Tab 4: EDF / CSV Ingestion & Export */}
      {activeTab === 'import_export' && (
        <div className="flex-1 grid grid-cols-1 md:grid-cols-2 gap-4 py-2">
          {/* Export Box */}
          <div className="bg-[#090C15] border border-slate-800 p-4 rounded flex flex-col justify-between">
            <div>
              <div className="flex items-center gap-2 text-slate-200 font-semibold text-xs mb-1">
                <Download className="w-4 h-4 text-cyan-400" />
                <span>Export Multi-Channel Biosignals</span>
              </div>
              <p className="text-[11px] text-slate-400 leading-relaxed">
                Export current recording buffers, filter configurations, event markers, and clinical annotations formatted for EEGLAB, MNE-Python, and OpenViBE analysis.
              </p>
            </div>
            <button
              onClick={onExportCsv}
              className="mt-4 flex items-center justify-center gap-2 px-4 py-2 bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold rounded text-xs transition-colors"
            >
              <Download className="w-4 h-4" />
              <span>Download Dataset (.CSV / .EDF Header)</span>
            </button>
          </div>

          {/* Import Box */}
          <div className="bg-[#090C15] border border-slate-800 p-4 rounded flex flex-col justify-between">
            <div>
              <div className="flex items-center gap-2 text-slate-200 font-semibold text-xs mb-1">
                <Upload className="w-4 h-4 text-emerald-400" />
                <span>Ingest Clinical Recording</span>
              </div>
              <p className="text-[11px] text-slate-400 leading-relaxed">
                Upload raw patient data in CSV, EDF, or ASCII format (e.g. BrainVision, OpenBCI, BioSemi, Ant Neuro) to simulate custom telemetry playback.
              </p>
            </div>
            <label className="mt-4 flex items-center justify-center gap-2 px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 font-medium rounded text-xs transition-colors cursor-pointer border border-slate-700">
              <Upload className="w-4 h-4 text-slate-400" />
              <span>Select Recording File</span>
              <input
                type="file"
                accept=".csv,.txt,.edf,.json"
                onChange={handleFileUpload}
                className="hidden"
              />
            </label>
          </div>
        </div>
      )}

      {/* Add Annotation Modal */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 bg-black/75 flex items-center justify-center p-4">
          <div className="bg-[#0E1322] border border-slate-700 rounded-lg p-5 w-full max-w-md shadow-2xl">
            <h3 className="text-sm font-semibold text-slate-100 mb-3">Add Clinical Event Annotation</h3>
            <form onSubmit={handleCreateAnnotation} className="space-y-3 text-xs">
              <div>
                <label className="block text-slate-400 mb-1">Annotation Label</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Epileptiform Sharp Wave Discharge"
                  value={newLabel}
                  onChange={(e) => setNewLabel(e.target.value)}
                  className="w-full bg-[#090C15] border border-slate-700 rounded px-2.5 py-1.5 text-slate-100 focus:outline-none focus:border-cyan-500"
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block text-slate-400 mb-1">Timestamp (seconds)</label>
                  <input
                    type="number"
                    step="0.01"
                    required
                    value={newTimestamp}
                    onChange={(e) => setNewTimestamp(e.target.value)}
                    className="w-full bg-[#090C15] border border-slate-700 rounded px-2.5 py-1.5 font-mono-data text-slate-100 focus:outline-none focus:border-cyan-500"
                  />
                </div>
                <div>
                  <label className="block text-slate-400 mb-1">Category</label>
                  <select
                    value={newCategory}
                    onChange={(e) => setNewCategory(e.target.value as any)}
                    className="w-full bg-[#090C15] border border-slate-700 rounded px-2.5 py-1.5 text-slate-100 focus:outline-none focus:border-cyan-500"
                  >
                    <option value="clinical_event">Clinical Event</option>
                    <option value="artifact">Artifact / Noise</option>
                    <option value="stimulus">Sensory Stimulus</option>
                    <option value="investigator_note">Investigator Note</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-slate-400 mb-1">Investigator Comments</label>
                <textarea
                  rows={2}
                  placeholder="Observations, morphology, or clinical relevance..."
                  value={newComments}
                  onChange={(e) => setNewComments(e.target.value)}
                  className="w-full bg-[#090C15] border border-slate-700 rounded px-2.5 py-1.5 text-slate-100 focus:outline-none focus:border-cyan-500"
                />
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="px-3 py-1.5 bg-slate-800 text-slate-300 rounded hover:bg-slate-700"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 bg-cyan-500 text-slate-950 font-bold rounded hover:bg-cyan-400"
                >
                  Save Annotation
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
