import React, { useRef, useEffect, useState, useMemo } from 'react';
import { ChannelInfo } from '../services/dspEngine';
import { Activity, Info, Zap } from 'lucide-react';

interface ScalpTopomapProps {
  channels: ChannelInfo[];
  signalBuffer: Record<string, number[]>;
  selectedChannelId: string;
  onSelectChannel: (channelId: string) => void;
}

export const ScalpTopomap: React.FC<ScalpTopomapProps> = ({
  channels,
  signalBuffer,
  selectedChannelId,
  onSelectChannel,
}) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const [selectedBand, setSelectedBand] = useState<'Alpha' | 'Beta' | 'Theta' | 'Delta' | 'Broadband'>('Alpha');
  const [colorScheme, setColorScheme] = useState<'coolwarm' | 'viridis'>('coolwarm');

  // Compute live RMS or power for each channel
  const channelPowers = useMemo(() => {
    const powers: Record<string, number> = {};
    channels.forEach((ch) => {
      const buffer = signalBuffer[ch.id] || [];
      if (buffer.length < 16) {
        powers[ch.id] = 5.0;
        return;
      }
      // Calculate recent power
      const recent = buffer.slice(-128);
      let sumSq = 0;
      for (let i = 0; i < recent.length; i++) {
        sumSq += recent[i] * recent[i];
      }
      const rms = Math.sqrt(sumSq / recent.length);

      // Simulate frequency-specific band scaling for realistic topological contrast
      let multiplier = 1.0;
      if (selectedBand === 'Alpha') {
        multiplier = (ch.lobe === 'Occipital' ? 2.8 : ch.lobe === 'Parietal' ? 1.9 : 0.8);
      } else if (selectedBand === 'Beta') {
        multiplier = (ch.lobe === 'Central' ? 2.2 : ch.lobe === 'Frontal' ? 1.8 : 0.9);
      } else if (selectedBand === 'Theta') {
        multiplier = (ch.lobe === 'Frontal' ? 2.4 : 1.0);
      } else if (selectedBand === 'Delta') {
        multiplier = (ch.lobe === 'Frontal' ? 2.5 : 1.2);
      }

      powers[ch.id] = Math.max(1, rms * multiplier);
    });
    return powers;
  }, [channels, signalBuffer, selectedBand]);

  // Frontal Alpha Asymmetry (FAA = ln(Alpha_F4) - ln(Alpha_F3))
  const faaIndex = useMemo(() => {
    const pF3 = channelPowers['F3'] || 5.0;
    const pF4 = channelPowers['F4'] || 5.0;
    return Math.log(Math.max(0.1, pF4)) - Math.log(Math.max(0.1, pF3));
  }, [channelPowers]);

  // Render 2D Scalp Head Canvas
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const dpr = window.devicePixelRatio || 1;
    const size = 320;
    canvas.width = size * dpr;
    canvas.height = size * dpr;

    ctx.save();
    ctx.scale(dpr, dpr);

    ctx.clearRect(0, 0, size, size);

    const cx = size / 2;
    const cy = size / 2 + 6;
    const radius = size * 0.38;

    // Filter EEG channels only for head map
    const eegChannels = channels.filter((c) => c.type === 'EEG');

    // Find min and max power for normalization
    let minPower = Infinity;
    let maxPower = -Infinity;
    eegChannels.forEach((c) => {
      const p = channelPowers[c.id] || 1;
      if (p < minPower) minPower = p;
      if (p > maxPower) maxPower = p;
    });
    if (minPower === maxPower) {
      maxPower = minPower + 1;
    }

    // 1. Draw Interpolated Scalp Power Grid
    const imgData = ctx.createImageData(size, size);
    const data = imgData.data;

    // Color ramp helper
    const getColor = (norm: number): [number, number, number] => {
      const val = Math.max(0, Math.min(1, norm));
      if (colorScheme === 'coolwarm') {
        // Deep blue (low) -> Teal -> Amber -> Ruby red (high)
        if (val < 0.33) {
          const t = val / 0.33;
          return [Math.floor(20 + 20 * t), Math.floor(60 + 120 * t), Math.floor(180 + 40 * t)];
        } else if (val < 0.66) {
          const t = (val - 0.33) / 0.33;
          return [Math.floor(40 + 180 * t), Math.floor(180 + 20 * t), Math.floor(220 - 150 * t)];
        } else {
          const t = (val - 0.66) / 0.34;
          return [Math.floor(220 + 35 * t), Math.floor(200 - 150 * t), Math.floor(70 - 40 * t)];
        }
      } else {
        // Viridis
        const r = Math.floor(68 + 185 * val);
        const g = Math.floor(1 + 230 * val);
        const b = Math.floor(84 + 20 * (1 - val));
        return [r, g, b];
      }
    };

    // Radial IDW (Inverse Distance Weighting) Interpolation inside head circle
    for (let py = 0; py < size; py += 2) {
      for (let px = 0; px < size; px += 2) {
        const dx = px - cx;
        const dy = py - cy;
        const distToCenter = Math.sqrt(dx * dx + dy * dy);

        if (distToCenter <= radius) {
          let numerator = 0;
          let denominator = 0;

          for (let i = 0; i < eegChannels.length; i++) {
            const ch = eegChannels[i];
            const chX = cx + ch.x * radius * 0.9;
            const chY = cy + ch.y * radius * 0.9;
            const dist = Math.hypot(px - chX, py - chY);
            const w = 1 / Math.pow(Math.max(12, dist), 2.2);

            const p = channelPowers[ch.id] || minPower;
            numerator += w * p;
            denominator += w;
          }

          const interpVal = denominator > 0 ? numerator / denominator : minPower;
          const normalized = (interpVal - minPower) / (maxPower - minPower);
          const [r, g, b] = getColor(normalized);

          // Write 2x2 block
          for (let subY = 0; subY < 2; subY++) {
            for (let subX = 0; subX < 2; subX++) {
              const idx = ((py + subY) * size + (px + subX)) * 4;
              data[idx] = r;
              data[idx + 1] = g;
              data[idx + 2] = b;
              data[idx + 3] = 220; // Slight translucency
            }
          }
        }
      }
    }

    ctx.putImageData(imgData, 0, 0);

    // 2. Draw Anatomical Markers (Nose & Ears)
    ctx.strokeStyle = '#94A3B8';
    ctx.lineWidth = 1.8;

    // Head boundary circle
    ctx.beginPath();
    ctx.arc(cx, cy, radius, 0, Math.PI * 2);
    ctx.stroke();

    // Nose Triangle (Superior)
    ctx.beginPath();
    ctx.moveTo(cx - 14, cy - radius + 2);
    ctx.lineTo(cx, cy - radius - 16);
    ctx.lineTo(cx + 14, cy - radius + 2);
    ctx.stroke();

    // Left Ear
    ctx.beginPath();
    ctx.arc(cx - radius - 2, cy, 14, -Math.PI / 2, Math.PI / 2, true);
    ctx.stroke();

    // Right Ear
    ctx.beginPath();
    ctx.arc(cx + radius + 2, cy, 14, -Math.PI / 2, Math.PI / 2, false);
    ctx.stroke();

    // 3. Render Electrode Nodes
    eegChannels.forEach((ch) => {
      const ex = cx + ch.x * radius * 0.9;
      const ey = cy + ch.y * radius * 0.9;
      const isSelected = ch.id === selectedChannelId;

      // Glow ring for selected
      if (isSelected) {
        ctx.beginPath();
        ctx.arc(ex, ey, 9, 0, Math.PI * 2);
        ctx.fillStyle = 'rgba(56, 189, 248, 0.4)';
        ctx.fill();
        ctx.strokeStyle = '#38BDF8';
        ctx.lineWidth = 2;
        ctx.stroke();
      }

      // Electrode dot
      ctx.beginPath();
      ctx.arc(ex, ey, 5, 0, Math.PI * 2);
      ctx.fillStyle = isSelected ? '#FFFFFF' : '#0F172A';
      ctx.fill();
      ctx.strokeStyle = isSelected ? '#38BDF8' : '#CBD5E1';
      ctx.lineWidth = 1.5;
      ctx.stroke();

      // Electrode name label
      ctx.fillStyle = '#FFFFFF';
      ctx.font = 'bold 9px "IBM Plex Mono", monospace';
      ctx.textAlign = 'center';
      ctx.shadowColor = 'rgba(0,0,0,0.8)';
      ctx.shadowBlur = 4;
      ctx.fillText(ch.name, ex, ey - 7);
      ctx.shadowBlur = 0;
    });

    ctx.restore();
  }, [channels, channelPowers, selectedChannelId, colorScheme, selectedBand]);

  // Handle electrode node clicks on the canvas
  const handleCanvasClick = (e: React.MouseEvent<HTMLCanvasElement>) => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const rect = canvas.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;

    const size = 320;
    const cx = size / 2;
    const cy = size / 2 + 6;
    const radius = size * 0.38;

    const eegChannels = channels.filter((c) => c.type === 'EEG');
    for (const ch of eegChannels) {
      const ex = cx + ch.x * radius * 0.9;
      const ey = cy + ch.y * radius * 0.9;
      const dist = Math.hypot(x - ex, y - ey);
      if (dist < 14) {
        onSelectChannel(ch.id);
        break;
      }
    }
  };

  const currentCh = channels.find((c) => c.id === selectedChannelId) || channels[0];

  return (
    <div className="flex flex-col h-full bg-[#0E1322] border border-slate-800 rounded-lg p-4">
      {/* Header & Band Selector */}
      <div className="flex items-center justify-between pb-3 border-b border-slate-800">
        <div className="flex items-center gap-2">
          <Activity className="w-4 h-4 text-cyan-400" />
          <h3 className="text-sm font-semibold text-slate-100">10-20 Scalp Topography</h3>
        </div>

        {/* Band Selector */}
        <div className="flex items-center gap-1 bg-slate-900 border border-slate-800 p-0.5 rounded text-xs">
          {(['Delta', 'Theta', 'Alpha', 'Beta', 'Broadband'] as const).map((band) => (
            <button
              key={band}
              onClick={() => setSelectedBand(band)}
              className={`px-2 py-0.5 rounded font-mono-data text-[11px] transition-colors ${
                selectedBand === band ? 'bg-cyan-500/20 text-cyan-300 font-semibold' : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              {band}
            </button>
          ))}
        </div>
      </div>

      {/* Main Scalp Stage & Color Scale */}
      <div className="flex flex-col items-center justify-center my-auto py-2">
        <canvas
          ref={canvasRef}
          onClick={handleCanvasClick}
          className="w-[300px] h-[300px] cursor-pointer"
        />

        {/* Colorbar Scale Legend */}
        <div className="flex items-center gap-2 w-64 mt-1">
          <span className="text-[10px] font-mono-data text-slate-400">0.0 µV²</span>
          <div
            className="flex-1 h-2 rounded"
            style={{
              background:
                colorScheme === 'coolwarm'
                  ? 'linear-gradient(to right, rgb(20,60,180), rgb(40,180,220), rgb(220,200,70), rgb(240,50,30))'
                  : 'linear-gradient(to right, #440154, #3b528b, #21908c, #5dc863, #fde725)',
            }}
          />
          <span className="text-[10px] font-mono-data text-slate-400">HIGH</span>
        </div>
      </div>

      {/* Selected Electrode Telemetry & Biomarker Info */}
      <div className="mt-auto pt-3 border-t border-slate-800 text-xs">
        <div className="grid grid-cols-2 gap-2 mb-2">
          <div className="bg-slate-900/80 border border-slate-800/80 p-2 rounded">
            <span className="text-[10px] font-mono-data text-slate-400 uppercase">SELECTED ELECTRODE</span>
            <div className="flex items-baseline gap-1.5 mt-0.5">
              <span className="text-base font-bold text-slate-100 font-mono-data">{currentCh.name}</span>
              <span className="text-[11px] text-slate-400">({currentCh.lobe} Lobe)</span>
            </div>
            <div className="text-[11px] font-mono-data text-emerald-400 mt-0.5">
              Contact: {currentCh.impedanceKOhms.toFixed(1)} kΩ · Normal
            </div>
          </div>

          <div className="bg-slate-900/80 border border-slate-800/80 p-2 rounded">
            <span className="text-[10px] font-mono-data text-slate-400 uppercase">FRONTAL ALPHA ASYMMETRY</span>
            <div className="flex items-baseline gap-1 mt-0.5">
              <span className={`text-base font-bold font-mono-data ${faaIndex >= 0 ? 'text-emerald-400' : 'text-amber-400'}`}>
                {faaIndex >= 0 ? `+${faaIndex.toFixed(3)}` : faaIndex.toFixed(3)}
              </span>
              <span className="text-[11px] text-slate-500 font-mono-data">ln(F4)-ln(F3)</span>
            </div>
            <div className="text-[10px] text-slate-400 mt-0.5 truncate">
              {faaIndex >= 0 ? 'Left Approach / Positive Affect' : 'Right Withdrawal Bias'}
            </div>
          </div>
        </div>

        <div className="flex items-center justify-between text-[11px] text-slate-400 px-1">
          <span>Click any electrode node to isolate signal trace</span>
          <button
            onClick={() => setColorScheme(colorScheme === 'coolwarm' ? 'viridis' : 'coolwarm')}
            className="text-cyan-400 hover:text-cyan-300 underline"
          >
            Ramp: {colorScheme.toUpperCase()}
          </button>
        </div>
      </div>
    </div>
  );
};
