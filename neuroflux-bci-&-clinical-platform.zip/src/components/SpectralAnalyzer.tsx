import React, { useMemo } from 'react';
import { ChannelInfo, computeFFT, calculateSpectralBands } from '../services/dspEngine';
import { BarChart3, TrendingUp, Cpu } from 'lucide-react';

interface SpectralAnalyzerProps {
  channels: ChannelInfo[];
  signalBuffer: Record<string, number[]>;
  selectedChannelId: string;
  onSelectChannel: (id: string) => void;
}

export const SpectralAnalyzer: React.FC<SpectralAnalyzerProps> = ({
  channels,
  signalBuffer,
  selectedChannelId,
  onSelectChannel,
}) => {
  const currentCh = channels.find((c) => c.id === selectedChannelId) || channels[0];
  const channelData = signalBuffer[currentCh?.id] || [];

  // Compute live FFT on recent window (256-512 samples)
  const { freqs, magnitudes, bands, peakFreq, spectralEntropy } = useMemo(() => {
    if (channelData.length < 64) {
      return {
        freqs: [],
        magnitudes: [],
        bands: [],
        peakFreq: 0,
        spectralEntropy: 0,
      };
    }

    const { freqs: f, magnitudes: m } = computeFFT(channelData);
    const calculatedBands = calculateSpectralBands(f, m);

    // Find peak frequency within 1 - 40 Hz
    let maxMag = -1;
    let peak = 10.0;
    for (let i = 0; i < f.length; i++) {
      if (f[i] >= 1.0 && f[i] <= 45.0) {
        if (m[i] > maxMag) {
          maxMag = m[i];
          peak = f[i];
        }
      }
    }

    // Compute spectral entropy: H = -sum(p * log2(p))
    let totalP = 0;
    for (let i = 0; i < m.length; i++) {
      totalP += m[i] * m[i];
    }
    let entropy = 0;
    if (totalP > 0) {
      for (let i = 0; i < m.length; i++) {
        const p = (m[i] * m[i]) / totalP;
        if (p > 1e-6) {
          entropy -= p * Math.log2(p);
        }
      }
      entropy = entropy / Math.log2(m.length); // Normalize 0 - 1
    }

    return {
      freqs: f,
      magnitudes: m,
      bands: calculatedBands,
      peakFreq: peak,
      spectralEntropy: Math.max(0, Math.min(1, entropy)),
    };
  }, [channelData]);

  // Max magnitude for SVG chart scaling
  const maxChartMag = useMemo(() => {
    let max = 0.5;
    for (let i = 0; i < magnitudes.length; i++) {
      if (freqs[i] <= 60 && magnitudes[i] > max) {
        max = magnitudes[i];
      }
    }
    return Math.max(5, max * 1.15);
  }, [magnitudes, freqs]);

  // SVG points for PSD line
  const psdSvgPoints = useMemo(() => {
    if (freqs.length === 0) return '';
    const width = 440;
    const height = 180;
    const maxFreq = 50; // up to 50 Hz on x-axis

    const pts: string[] = [];
    for (let i = 0; i < freqs.length; i++) {
      if (freqs[i] > maxFreq) break;
      const x = (freqs[i] / maxFreq) * width;
      const y = height - (magnitudes[i] / maxChartMag) * height;
      pts.push(`${x.toFixed(1)},${y.toFixed(1)}`);
    }
    return pts.join(' ');
  }, [freqs, magnitudes, maxChartMag]);

  return (
    <div className="flex flex-col h-full bg-[#0E1322] border border-slate-800 rounded-lg p-4">
      {/* Header with Channel Switcher */}
      <div className="flex items-center justify-between pb-3 border-b border-slate-800">
        <div className="flex items-center gap-2">
          <BarChart3 className="w-4 h-4 text-cyan-400" />
          <h3 className="text-sm font-semibold text-slate-100">Power Spectral Density (PSD)</h3>
        </div>

        {/* Channel Dropdown */}
        <div className="flex items-center gap-1.5 text-xs">
          <span className="text-slate-400 font-mono-data">PROBE:</span>
          <select
            value={selectedChannelId}
            onChange={(e) => onSelectChannel(e.target.value)}
            className="bg-slate-900 border border-slate-700 text-slate-200 text-xs px-2.5 py-1 rounded font-mono-data focus:outline-none focus:border-cyan-500"
          >
            {channels.map((ch) => (
              <option key={ch.id} value={ch.id}>
                {ch.name} ({ch.lobe})
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* PSD Graph & Spectral Metrics */}
      <div className="flex flex-col gap-3 my-2">
        {/* SVG PSD Chart */}
        <div className="relative w-full h-[180px] bg-[#090C15] border border-slate-800 rounded overflow-hidden">
          {/* Frequency Band Background Shading */}
          <div className="absolute inset-0 flex pointer-events-none">
            {/* Delta 0 - 4 Hz (8%) */}
            <div className="w-[8%] h-full bg-indigo-950/20 border-r border-indigo-900/30 flex items-start p-1">
              <span className="text-[9px] font-mono-data text-indigo-400">δ</span>
            </div>
            {/* Theta 4 - 8 Hz (8%) */}
            <div className="w-[8%] h-full bg-sky-950/20 border-r border-sky-900/30 flex items-start p-1">
              <span className="text-[9px] font-mono-data text-sky-400">θ</span>
            </div>
            {/* Alpha 8 - 13 Hz (10%) */}
            <div className="w-[10%] h-full bg-emerald-950/25 border-r border-emerald-900/30 flex items-start p-1">
              <span className="text-[9px] font-mono-data text-emerald-400">α</span>
            </div>
            {/* Beta 13 - 30 Hz (34%) */}
            <div className="w-[34%] h-full bg-amber-950/20 border-r border-amber-900/30 flex items-start p-1">
              <span className="text-[9px] font-mono-data text-amber-400">β</span>
            </div>
            {/* Gamma 30 - 50 Hz (40%) */}
            <div className="w-[40%] h-full bg-rose-950/20 flex items-start p-1">
              <span className="text-[9px] font-mono-data text-rose-400">γ</span>
            </div>
          </div>

          {/* SVG Spectral Curve */}
          <svg className="w-full h-full" viewBox="0 0 440 180" preserveAspectRatio="none">
            {psdSvgPoints && (
              <>
                <polyline
                  fill="none"
                  stroke="#38BDF8"
                  strokeWidth="2"
                  strokeLinejoin="round"
                  points={psdSvgPoints}
                />
                {/* Area under curve */}
                <polygon
                  fill="rgba(56, 189, 248, 0.12)"
                  points={`0,180 ${psdSvgPoints} 440,180`}
                />
              </>
            )}
          </svg>

          {/* Frequency Axis Ticks */}
          <div className="absolute bottom-1 left-2 right-2 flex justify-between text-[10px] font-mono-data text-slate-500 pointer-events-none">
            <span>0 Hz</span>
            <span>10 Hz</span>
            <span>20 Hz</span>
            <span>30 Hz</span>
            <span>40 Hz</span>
            <span>50 Hz</span>
          </div>
        </div>

        {/* Real-Time Spectral KPIs */}
        <div className="grid grid-cols-3 gap-2">
          <div className="bg-slate-900/80 border border-slate-800 p-2 rounded">
            <span className="text-[10px] font-mono-data text-slate-400 uppercase">PEAK DOMINANT FREQ</span>
            <div className="flex items-baseline gap-1 mt-0.5">
              <span className="text-xl font-bold font-mono-data text-slate-100">{peakFreq.toFixed(1)}</span>
              <span className="text-xs font-mono-data text-cyan-400">Hz</span>
            </div>
            <div className="text-[10px] text-slate-400 mt-0.5">
              {peakFreq >= 8 && peakFreq <= 13 ? 'Posterior Alpha Rhythm' : peakFreq > 13 ? 'Beta Desynchronization' : 'Slow Wave'}
            </div>
          </div>

          <div className="bg-slate-900/80 border border-slate-800 p-2 rounded">
            <span className="text-[10px] font-mono-data text-slate-400 uppercase">SPECTRAL ENTROPY</span>
            <div className="flex items-baseline gap-1 mt-0.5">
              <span className="text-xl font-bold font-mono-data text-slate-100">{(spectralEntropy * 100).toFixed(1)}</span>
              <span className="text-xs font-mono-data text-slate-400">%</span>
            </div>
            <div className="text-[10px] text-slate-400 mt-0.5">
              {spectralEntropy > 0.75 ? 'Broadband Desynchronized' : 'Rhythmic Synchronization'}
            </div>
          </div>

          <div className="bg-slate-900/80 border border-slate-800 p-2 rounded">
            <span className="text-[10px] font-mono-data text-slate-400 uppercase">TOTAL SPECTRAL POWER</span>
            <div className="flex items-baseline gap-1 mt-0.5">
              <span className="text-xl font-bold font-mono-data text-emerald-400">
                {bands.reduce((sum, b) => sum + b.power, 0).toFixed(1)}
              </span>
              <span className="text-xs font-mono-data text-slate-400">µV²</span>
            </div>
            <div className="text-[10px] text-slate-400 mt-0.5 truncate">
              Nyquist 125 Hz · 512 pt FFT
            </div>
          </div>
        </div>
      </div>

      {/* Relative Band Power Table */}
      <div className="mt-auto border-t border-slate-800 pt-3">
        <h4 className="text-[11px] font-mono-data uppercase text-slate-400 mb-2">BAND POWER DECOMPOSITION</h4>
        <div className="space-y-1.5">
          {bands.map((band) => (
            <div key={band.name} className="flex items-center gap-2 text-xs font-mono-data">
              <span className="w-14 text-slate-300 font-semibold">{band.name}</span>
              <span className="w-18 text-[11px] text-slate-400">
                {band.freqRange[0]}-{band.freqRange[1]}Hz
              </span>
              <div className="flex-1 bg-slate-900 h-2 rounded overflow-hidden">
                <div
                  className="h-full rounded transition-all duration-300"
                  style={{
                    width: `${Math.min(100, band.relativePower)}%`,
                    backgroundColor: band.color,
                  }}
                />
              </div>
              <span className="w-12 text-right font-medium text-slate-200">
                {band.relativePower.toFixed(1)}%
              </span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
