import React, { useState } from 'react';
import { FilterConfig, ChannelInfo } from '../services/dspEngine';
import { Sliders, Cpu, Brain, Zap, Target, CheckCircle2, AlertTriangle, PlayCircle } from 'lucide-react';

interface BciWorkbenchProps {
  filterConfig: FilterConfig;
  onUpdateFilterConfig: (config: FilterConfig) => void;
  channels: ChannelInfo[];
  motorState: 'none' | 'left' | 'right';
  onSetMotorState: (state: 'none' | 'left' | 'right') => void;
  onTriggerP300: (isOddball: boolean) => void;
  emgContraction: number;
  onSetEmgContraction: (val: number) => void;
  signalBuffer: Record<string, number[]>;
}

export const BciWorkbench: React.FC<BciWorkbenchProps> = ({
  filterConfig,
  onUpdateFilterConfig,
  channels,
  motorState,
  onSetMotorState,
  onTriggerP300,
  emgContraction,
  onSetEmgContraction,
  signalBuffer,
}) => {
  const [activeTab, setActiveTab] = useState<'filters' | 'motor_imagery' | 'p300_erp' | 'emg_fatigue' | 'impedance'>('motor_imagery');

  // Compute live ERD metric between C3 and C4
  const c3Data = signalBuffer['C3'] || [];
  const c4Data = signalBuffer['C4'] || [];

  let c3Rms = 12.0;
  let c4Rms = 12.0;
  if (c3Data.length >= 64) {
    const recent3 = c3Data.slice(-64);
    c3Rms = Math.sqrt(recent3.reduce((acc, v) => acc + v * v, 0) / recent3.length);
  }
  if (c4Data.length >= 64) {
    const recent4 = c4Data.slice(-64);
    c4Rms = Math.sqrt(recent4.reduce((acc, v) => acc + v * v, 0) / recent4.length);
  }

  // Lateralized Desynchronization Index
  const lateralizationIndex = ((c4Rms - c3Rms) / (c4Rms + c3Rms + 0.001)) * 100;

  return (
    <div className="flex flex-col h-full bg-[#0E1322] border border-slate-800 rounded-lg p-4">
      {/* Header and Paradigm Switcher */}
      <div className="flex flex-wrap items-center justify-between gap-2 pb-3 border-b border-slate-800">
        <div className="flex items-center gap-2">
          <Cpu className="w-4 h-4 text-cyan-400" />
          <h3 className="text-sm font-semibold text-slate-100">BCI Signal Processing & Neural Decoder</h3>
        </div>

        {/* Tab Buttons */}
        <div className="flex items-center gap-1 bg-slate-900 border border-slate-800 p-0.5 rounded text-xs">
          <button
            onClick={() => setActiveTab('motor_imagery')}
            className={`px-3 py-1 font-medium rounded transition-colors whitespace-nowrap ${
              activeTab === 'motor_imagery' ? 'bg-cyan-500/20 text-cyan-300 font-semibold' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Motor Imagery (CSP)
          </button>
          <button
            onClick={() => setActiveTab('p300_erp')}
            className={`px-3 py-1 font-medium rounded transition-colors whitespace-nowrap ${
              activeTab === 'p300_erp' ? 'bg-cyan-500/20 text-cyan-300 font-semibold' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            P300 ERP Averager
          </button>
          <button
            onClick={() => setActiveTab('emg_fatigue')}
            className={`px-3 py-1 font-medium rounded transition-colors whitespace-nowrap ${
              activeTab === 'emg_fatigue' ? 'bg-cyan-500/20 text-cyan-300 font-semibold' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            EMG Fatigue & RMS
          </button>
          <button
            onClick={() => setActiveTab('filters')}
            className={`px-3 py-1 font-medium rounded transition-colors whitespace-nowrap ${
              activeTab === 'filters' ? 'bg-cyan-500/20 text-cyan-300 font-semibold' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            IIR Filter DSP
          </button>
          <button
            onClick={() => setActiveTab('impedance')}
            className={`px-3 py-1 font-medium rounded transition-colors whitespace-nowrap ${
              activeTab === 'impedance' ? 'bg-cyan-500/20 text-cyan-300 font-semibold' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Impedance Matrix
          </button>
        </div>
      </div>

      {/* Tab 1: Motor Imagery Decoder */}
      {activeTab === 'motor_imagery' && (
        <div className="flex-1 flex flex-col justify-between py-2 space-y-4">
          <div>
            <div className="flex items-center justify-between text-xs text-slate-400 mb-2">
              <span>Sensorimotor Mu/Beta Rhythm Decoder (10 Hz & 20 Hz)</span>
              <span className="font-mono-data text-emerald-400">CLASSIFIER ACCURACY: 92.4% (ROC-AUC: 0.96)</span>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
              {/* Left Motor Strip C3 */}
              <div className="bg-[#090C15] border border-slate-800 p-3 rounded">
                <div className="flex items-center justify-between text-xs font-mono-data text-slate-400">
                  <span>C3 (LEFT CORTEX)</span>
                  <span className="text-purple-400">Right Hand Control</span>
                </div>
                <div className="flex items-baseline gap-2 mt-2">
                  <span className="text-2xl font-bold font-mono-data text-slate-100">{c3Rms.toFixed(1)}</span>
                  <span className="text-xs text-slate-400 font-mono-data">µV RMS</span>
                </div>
                <div className="w-full bg-slate-900 h-2 rounded mt-2 overflow-hidden">
                  <div
                    className="h-full bg-purple-500 transition-all duration-200"
                    style={{ width: `${Math.min(100, (c3Rms / 25) * 100)}%` }}
                  />
                </div>
                <div className="text-[11px] text-slate-400 mt-1.5">
                  {motorState === 'right' ? 'Contralateral Desynchronization (ERD)' : 'Basal Idle Mu (10Hz)'}
                </div>
              </div>

              {/* Lateralization Indicator */}
              <div className="bg-[#090C15] border border-slate-800 p-3 rounded flex flex-col justify-between">
                <div className="text-xs font-mono-data text-slate-400 uppercase">
                  LATERALIZATION INDEX
                </div>
                <div className="text-center my-1">
                  <span className={`text-2xl font-bold font-mono-data ${lateralizationIndex > 10 ? 'text-amber-400' : lateralizationIndex < -10 ? 'text-cyan-400' : 'text-slate-300'}`}>
                    {lateralizationIndex > 0 ? `+${lateralizationIndex.toFixed(1)}` : lateralizationIndex.toFixed(1)}%
                  </span>
                  <div className="text-[11px] font-mono-data text-slate-400 mt-0.5">
                    {lateralizationIndex > 15
                      ? '▶ DETECTED: RIGHT HAND INTENT'
                      : lateralizationIndex < -15
                      ? '◀ DETECTED: LEFT HAND INTENT'
                      : 'REST STATE / NO INTENTION'}
                  </div>
                </div>
                <div className="flex justify-between text-[10px] font-mono-data text-slate-500">
                  <span>LEFT INTENT</span>
                  <span>BALANCED</span>
                  <span>RIGHT INTENT</span>
                </div>
              </div>

              {/* Right Motor Strip C4 */}
              <div className="bg-[#090C15] border border-slate-800 p-3 rounded">
                <div className="flex items-center justify-between text-xs font-mono-data text-slate-400">
                  <span>C4 (RIGHT CORTEX)</span>
                  <span className="text-purple-400">Left Hand Control</span>
                </div>
                <div className="flex items-baseline gap-2 mt-2">
                  <span className="text-2xl font-bold font-mono-data text-slate-100">{c4Rms.toFixed(1)}</span>
                  <span className="text-xs text-slate-400 font-mono-data">µV RMS</span>
                </div>
                <div className="w-full bg-slate-900 h-2 rounded mt-2 overflow-hidden">
                  <div
                    className="h-full bg-purple-500 transition-all duration-200"
                    style={{ width: `${Math.min(100, (c4Rms / 25) * 100)}%` }}
                  />
                </div>
                <div className="text-[11px] text-slate-400 mt-1.5">
                  {motorState === 'left' ? 'Contralateral Desynchronization (ERD)' : 'Basal Idle Mu (10Hz)'}
                </div>
              </div>
            </div>
          </div>

          {/* Interactive BCI Simulation Controls */}
          <div className="bg-slate-900/60 border border-slate-800 p-3 rounded-lg">
            <h4 className="text-xs font-semibold text-slate-200 mb-2">Subject Motor Imagery Cue Injection:</h4>
            <div className="flex flex-wrap items-center gap-3">
              <button
                onClick={() => onSetMotorState('left')}
                className={`flex items-center gap-2 px-4 py-2 rounded text-xs font-medium transition-colors ${
                  motorState === 'left'
                    ? 'bg-cyan-500 text-slate-950 font-bold shadow-sm'
                    : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
                }`}
              >
                <span>Trigger Left Hand Imagery (C4 ERD)</span>
              </button>

              <button
                onClick={() => onSetMotorState('right')}
                className={`flex items-center gap-2 px-4 py-2 rounded text-xs font-medium transition-colors ${
                  motorState === 'right'
                    ? 'bg-amber-500 text-slate-950 font-bold shadow-sm'
                    : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
                }`}
              >
                <span>Trigger Right Hand Imagery (C3 ERD)</span>
              </button>

              <button
                onClick={() => onSetMotorState('none')}
                className={`px-4 py-2 rounded text-xs font-medium transition-colors ${
                  motorState === 'none'
                    ? 'bg-slate-700 text-white font-semibold'
                    : 'bg-slate-800 text-slate-400 hover:bg-slate-700'
                }`}
              >
                Rest / Baseline
              </button>
            </div>
            <p className="text-[11px] text-slate-400 mt-2">
              Injecting motor imagery cues alters contralateral sensorimotor mu rhythm amplitude on the live oscilloscope in real time.
            </p>
          </div>
        </div>
      )}

      {/* Tab 2: P300 Oddball ERP Averager */}
      {activeTab === 'p300_erp' && (
        <div className="flex-1 flex flex-col justify-between py-2 space-y-4">
          <div className="flex items-center justify-between text-xs text-slate-400">
            <span>Synchronous Trial Averaging Window: -200ms to +800ms</span>
            <span className="font-mono-data text-cyan-400">TARGET EPOCHS: 34 · SNR: 14.8 dB</span>
          </div>

          {/* Synthetic P300 Waveform Visualizer */}
          <div className="relative w-full h-44 bg-[#090C15] border border-slate-800 rounded p-2 overflow-hidden">
            {/* Zero latency line */}
            <div className="absolute top-0 bottom-0 left-[20%] w-px bg-slate-700" />
            <span className="absolute top-2 left-[21%] text-[10px] font-mono-data text-slate-500">Stimulus Onset (0ms)</span>

            {/* +300ms line */}
            <div className="absolute top-0 bottom-0 left-[52%] w-px bg-amber-500/40 border-dashed" />
            <span className="absolute top-2 left-[53%] text-[10px] font-mono-data text-amber-400">P3b Peak (+320ms)</span>

            {/* SVG Comparison Curve */}
            <svg className="w-full h-full" viewBox="0 0 500 160" preserveAspectRatio="none">
              {/* Baseline Non-Target Curve (Blue) */}
              <path
                d="M 0,80 Q 50,80 100,80 T 150,100 T 200,60 T 260,80 T 350,80 T 500,80"
                fill="none"
                stroke="#60A5FA"
                strokeWidth="1.5"
                strokeDasharray="4,2"
              />
              {/* Rare Target P300 Curve (Amber) */}
              <path
                d="M 0,80 Q 50,80 100,80 T 150,110 T 200,50 Q 260,10 320,10 T 380,60 T 440,80 T 500,80"
                fill="none"
                stroke="#F59E0B"
                strokeWidth="2.5"
              />
            </svg>

            <div className="absolute bottom-2 right-3 flex items-center gap-4 text-[11px] font-mono-data">
              <div className="flex items-center gap-1.5">
                <span className="w-3 h-0.5 bg-amber-400" />
                <span className="text-amber-300">Target Tone S2 (P3b = 16.4 µV)</span>
              </div>
              <div className="flex items-center gap-1.5">
                <span className="w-3 h-0.5 bg-blue-400 border-dashed" />
                <span className="text-slate-400">Non-Target Tone S1</span>
              </div>
            </div>
          </div>

          {/* Trigger Tone Controls */}
          <div className="flex flex-wrap items-center justify-between gap-3 bg-slate-900/60 border border-slate-800 p-3 rounded">
            <div className="text-xs text-slate-300">
              <div className="font-semibold text-slate-100">Manual Auditory Stimulus Injection:</div>
              <div className="text-[11px] text-slate-400">Trigger standard or rare oddball tone to observe parietal Pz deflection.</div>
            </div>
            <div className="flex items-center gap-2">
              <button
                onClick={() => onTriggerP300(false)}
                className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded text-xs font-mono-data"
              >
                Send Tone S1 (500Hz)
              </button>
              <button
                onClick={() => onTriggerP300(true)}
                className="px-3 py-1.5 bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold rounded text-xs font-mono-data"
              >
                Send Rare Target S2 (1000Hz)
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Tab 3: EMG Fatigue & Envelope */}
      {activeTab === 'emg_fatigue' && (
        <div className="flex-1 flex flex-col justify-between py-2 space-y-4">
          <div className="flex items-center justify-between text-xs text-slate-400">
            <span>High-Density Surface EMG Signal Processing (0-450 Hz)</span>
            <span className="font-mono-data text-amber-400">MEDIAN FREQ: {(142 - emgContraction * 28).toFixed(1)} Hz (FATIGUE SHIFT)</span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            <div className="bg-[#090C15] border border-slate-800 p-3 rounded">
              <span className="text-xs font-mono-data text-slate-400 uppercase">CONTRACTION RECRUITMENT</span>
              <div className="flex items-baseline gap-2 mt-2">
                <span className="text-3xl font-bold font-mono-data text-amber-400">
                  {(emgContraction * 100).toFixed(0)}%
                </span>
                <span className="text-xs font-mono-data text-slate-400">Max Voluntary Contraction (MVC)</span>
              </div>
              <input
                type="range"
                min="0"
                max="1"
                step="0.05"
                value={emgContraction}
                onChange={(e) => onSetEmgContraction(parseFloat(e.target.value))}
                className="w-full mt-3 accent-amber-400 cursor-pointer"
              />
              <div className="flex justify-between text-[10px] font-mono-data text-slate-500 mt-1">
                <span>0% REST</span>
                <span>50% MODERATE</span>
                <span>100% MAXIMUM</span>
              </div>
            </div>

            <div className="bg-[#090C15] border border-slate-800 p-3 rounded">
              <span className="text-xs font-mono-data text-slate-400 uppercase">ROOT MEAN SQUARE (RMS) ENVELOPE</span>
              <div className="flex items-baseline gap-2 mt-2">
                <span className="text-3xl font-bold font-mono-data text-slate-100">
                  {(12 + emgContraction * 180).toFixed(1)}
                </span>
                <span className="text-xs font-mono-data text-slate-400">µV RMS</span>
              </div>
              <div className="w-full bg-slate-900 h-3 rounded mt-3 overflow-hidden">
                <div
                  className="h-full bg-amber-500 transition-all duration-150"
                  style={{ width: `${Math.min(100, ((12 + emgContraction * 180) / 200) * 100)}%` }}
                />
              </div>
              <div className="text-[11px] text-slate-400 mt-2">
                Linear motor unit recruitment with isometric forearm load.
              </div>
            </div>
          </div>

          <div className="bg-slate-900/60 border border-slate-800 p-3 rounded text-xs text-slate-300">
            <span className="font-semibold text-slate-200">Clinical Neuromuscular Application:</span>
            <p className="text-[11px] text-slate-400 mt-1">
              Used in SMA and ALS clinical trials to measure motor unit action potential (MUAP) decay and myoelectric spectral compression over sustained isometric contractions.
            </p>
          </div>
        </div>
      )}

      {/* Tab 4: IIR Filter DSP Controls */}
      {activeTab === 'filters' && (
        <div className="flex-1 flex flex-col justify-between py-2 space-y-3">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {/* Bandpass Filter Controls */}
            <div className="bg-[#090C15] border border-slate-800 p-3 rounded space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-xs font-semibold text-slate-200">Butterworth Bandpass Filter</span>
                <label className="relative inline-flex items-center cursor-pointer">
                  <input
                    type="checkbox"
                    checked={filterConfig.enableBandpass}
                    onChange={(e) => onUpdateFilterConfig({ ...filterConfig, enableBandpass: e.target.checked })}
                    className="sr-only peer"
                  />
                  <div className="w-9 h-5 bg-slate-800 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-cyan-500"></div>
                </label>
              </div>

              <div>
                <div className="flex justify-between text-xs font-mono-data text-slate-400">
                  <span>High-Pass Cutoff (Detrend):</span>
                  <span className="text-cyan-400">{filterConfig.highPassCutoff} Hz</span>
                </div>
                <input
                  type="range"
                  min="0.1"
                  max="5.0"
                  step="0.1"
                  value={filterConfig.highPassCutoff}
                  onChange={(e) => onUpdateFilterConfig({ ...filterConfig, highPassCutoff: parseFloat(e.target.value) })}
                  className="w-full accent-cyan-400 cursor-pointer"
                />
              </div>

              <div>
                <div className="flex justify-between text-xs font-mono-data text-slate-400">
                  <span>Low-Pass Cutoff (Anti-Alias):</span>
                  <span className="text-cyan-400">{filterConfig.lowPassCutoff} Hz</span>
                </div>
                <input
                  type="range"
                  min="15"
                  max="100"
                  step="1"
                  value={filterConfig.lowPassCutoff}
                  onChange={(e) => onUpdateFilterConfig({ ...filterConfig, lowPassCutoff: parseFloat(e.target.value) })}
                  className="w-full accent-cyan-400 cursor-pointer"
                />
              </div>
            </div>

            {/* Mains Hum Suppression (Notch) */}
            <div className="bg-[#090C15] border border-slate-800 p-3 rounded space-y-3">
              <span className="text-xs font-semibold text-slate-200">Mains Hum Suppression (IIR Notch)</span>

              <div className="flex items-center justify-between p-2 bg-slate-900 border border-slate-800 rounded">
                <span className="text-xs font-mono-data text-slate-300">50 Hz Notch (EU/UK/Asia Powerline)</span>
                <button
                  onClick={() => onUpdateFilterConfig({ ...filterConfig, notch50Hz: !filterConfig.notch50Hz })}
                  className={`px-3 py-1 text-xs font-mono-data rounded ${
                    filterConfig.notch50Hz ? 'bg-emerald-500 text-slate-950 font-bold' : 'bg-slate-800 text-slate-400'
                  }`}
                >
                  {filterConfig.notch50Hz ? 'ACTIVE' : 'BYPASS'}
                </button>
              </div>

              <div className="flex items-center justify-between p-2 bg-slate-900 border border-slate-800 rounded">
                <span className="text-xs font-mono-data text-slate-300">60 Hz Notch (US/Americas Powerline)</span>
                <button
                  onClick={() => onUpdateFilterConfig({ ...filterConfig, notch60Hz: !filterConfig.notch60Hz })}
                  className={`px-3 py-1 text-xs font-mono-data rounded ${
                    filterConfig.notch60Hz ? 'bg-emerald-500 text-slate-950 font-bold' : 'bg-slate-800 text-slate-400'
                  }`}
                >
                  {filterConfig.notch60Hz ? 'ACTIVE' : 'BYPASS'}
                </button>
              </div>

              <div className="flex items-center justify-between p-2 bg-slate-900 border border-slate-800 rounded">
                <span className="text-xs font-mono-data text-slate-300">EMG Moving RMS Envelope Mode</span>
                <button
                  onClick={() => onUpdateFilterConfig({ ...filterConfig, emgEnvelope: !filterConfig.emgEnvelope })}
                  className={`px-3 py-1 text-xs font-mono-data rounded ${
                    filterConfig.emgEnvelope ? 'bg-amber-500 text-slate-950 font-bold' : 'bg-slate-800 text-slate-400'
                  }`}
                >
                  {filterConfig.emgEnvelope ? 'ACTIVE' : 'OFF'}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Tab 5: Electrode Impedance Matrix */}
      {activeTab === 'impedance' && (
        <div className="flex-1 flex flex-col justify-between py-2 space-y-3">
          <div className="flex items-center justify-between text-xs text-slate-400">
            <span>Electrode-Skin Interface Contact Impedance Quality (1 kHz AC Probe)</span>
            <span className="font-mono-data text-emerald-400">16 / 16 ELECTRODES OPERATIONAL</span>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-4 md:grid-cols-8 gap-2">
            {channels.map((ch) => {
              const status = ch.impedanceKOhms < 5 ? 'nominal' : ch.impedanceKOhms < 10 ? 'warning' : 'poor';
              return (
                <div
                  key={ch.id}
                  className="bg-[#090C15] border border-slate-800 p-2 rounded text-center"
                >
                  <div className="text-xs font-mono-data font-bold text-slate-200">{ch.name}</div>
                  <div className="text-[10px] text-slate-500">{ch.lobe}</div>
                  <div className={`text-sm font-mono-data font-semibold mt-1 ${
                    status === 'nominal' ? 'text-emerald-400' : status === 'warning' ? 'text-amber-400' : 'text-rose-400'
                  }`}>
                    {ch.impedanceKOhms.toFixed(1)}kΩ
                  </div>
                  <div className="text-[9px] font-mono-data uppercase text-slate-400 mt-0.5">
                    {status === 'nominal' ? 'GOOD' : status === 'warning' ? 'HIGH' : 'POOR'}
                  </div>
                </div>
              );
            })}
          </div>

          <div className="flex items-center justify-between text-xs text-slate-400 bg-slate-900/50 p-2.5 rounded border border-slate-800">
            <div className="flex items-center gap-4">
              <span className="flex items-center gap-1.5">
                <span className="w-2.5 h-2.5 rounded-full bg-emerald-400" />
                <span>&lt; 5.0 kΩ (Clinical Gold Standard)</span>
              </span>
              <span className="flex items-center gap-1.5">
                <span className="w-2.5 h-2.5 rounded-full bg-amber-400" />
                <span>5.0 - 10.0 kΩ (Acceptable)</span>
              </span>
              <span className="flex items-center gap-1.5">
                <span className="w-2.5 h-2.5 rounded-full bg-rose-400" />
                <span>&gt; 10.0 kΩ (Requires Prep)</span>
              </span>
            </div>
            <span className="text-[11px] font-mono-data text-slate-400">24-bit Sigma-Delta ADC Baseline</span>
          </div>
        </div>
      )}
    </div>
  );
};
