import React, { useRef, useEffect, useState, useMemo, useCallback } from 'react';
import { ChannelInfo, MarkerEvent, FilterConfig, ChannelFilterPipeline } from '../services/dspEngine';
import { AnnotationItem } from '../data/clinicalTrials';
import { Play, Pause, RotateCcw, ZoomIn, ZoomOut, Eye, EyeOff, Layers, Sliders, Volume2, ShieldCheck, AlertCircle } from 'lucide-react';

interface OscilloscopeCanvasProps {
  channels: ChannelInfo[];
  signalBuffer: Record<string, number[]>; // time series arrays
  timeStamps: number[];
  filterConfig: FilterConfig;
  events: MarkerEvent[];
  annotations: AnnotationItem[];
  isPlaying: boolean;
  onTogglePlay: () => void;
  onReset: () => void;
  onAddAnnotation: (timestampSec: number, channelId?: string) => void;
  gainMicroVolts: number;
  setGainMicroVolts: (gain: number) => void;
  timeWindowSec: number;
  setTimeWindowSec: (sec: number) => void;
  showFiltered: boolean;
  setShowFiltered: (val: boolean) => void;
  samplingRate: number;
  activeLobeFilter: string;
  setActiveLobeFilter: (lobe: string) => void;
}

export const OscilloscopeCanvas: React.FC<OscilloscopeCanvasProps> = ({
  channels,
  signalBuffer,
  timeStamps,
  filterConfig,
  events,
  annotations,
  isPlaying,
  onTogglePlay,
  onReset,
  onAddAnnotation,
  gainMicroVolts,
  setGainMicroVolts,
  timeWindowSec,
  setTimeWindowSec,
  showFiltered,
  setShowFiltered,
  samplingRate,
  activeLobeFilter,
  setActiveLobeFilter,
}) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const containerRef = useRef<HTMLDivElement | null>(null);

  const [hoverInfo, setHoverInfo] = useState<{
    x: number;
    y: number;
    timeSec: number;
    channelName: string;
    valueUv: number;
  } | null>(null);

  const [toggledChannels, setToggledChannels] = useState<Record<string, boolean>>({});

  // Filter pipelines cache per channel
  const filterPipelines = useMemo(() => {
    const map = new Map<string, ChannelFilterPipeline>();
    channels.forEach((ch) => {
      map.set(ch.id, new ChannelFilterPipeline(samplingRate));
    });
    return map;
  }, [channels, samplingRate]);

  // Update pipeline configs when filter settings change
  useEffect(() => {
    filterPipelines.forEach((pipeline) => {
      pipeline.updateConfig(filterConfig, samplingRate);
    });
  }, [filterPipelines, filterConfig, samplingRate]);

  // Visible channels filtered by lobe selector & channel toggle
  const visibleChannels = useMemo(() => {
    return channels.filter((ch) => {
      const isLobeMatch = activeLobeFilter === 'ALL' || ch.lobe === activeLobeFilter;
      const isIndividuallyVisible = toggledChannels[ch.id] !== false;
      return ch.visible && isLobeMatch && isIndividuallyVisible;
    });
  }, [channels, activeLobeFilter, toggledChannels]);

  // Toggle individual channel visibility
  const toggleChannel = (id: string) => {
    setToggledChannels((prev) => ({
      ...prev,
      [id]: prev[id] === undefined ? false : !prev[id],
    }));
  };

  // High performance canvas renderer
  const renderCanvas = useCallback(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const dpr = window.devicePixelRatio || 1;
    const width = canvas.clientWidth;
    const height = canvas.clientHeight;

    if (canvas.width !== width * dpr || canvas.height !== height * dpr) {
      canvas.width = width * dpr;
      canvas.height = height * dpr;
    }

    ctx.save();
    ctx.scale(dpr, dpr);

    // Dark scientific canvas background
    ctx.fillStyle = '#090C15';
    ctx.fillRect(0, 0, width, height);

    if (visibleChannels.length === 0 || timeStamps.length < 2) {
      ctx.fillStyle = '#64748B';
      ctx.font = '13px "IBM Plex Mono", monospace';
      ctx.textAlign = 'center';
      ctx.fillText('NO BIOSIGNAL CHANNELS ACTIVE · SELECT CHANNELS TO RESUME SWEEP', width / 2, height / 2);
      ctx.restore();
      return;
    }

    const channelHeight = height / visibleChannels.length;
    const totalSamples = timeStamps.length;
    const latestTime = timeStamps[totalSamples - 1] / 1000;
    const startTime = Math.max(0, latestTime - timeWindowSec);

    // 1. Draw Time Grid (Vertical lines every 1.0 second and 0.2 second)
    const startSec = Math.floor(startTime);
    const endSec = Math.ceil(latestTime);

    for (let s = startSec; s <= endSec; s += 0.2) {
      const isMajor = Math.abs(Math.round(s) - s) < 0.05;
      const x = ((s - startTime) / timeWindowSec) * width;
      if (x < 0 || x > width) continue;

      ctx.beginPath();
      ctx.strokeStyle = isMajor ? '#1E293B' : '#111827';
      ctx.lineWidth = isMajor ? 1.0 : 0.5;
      ctx.moveTo(x, 0);
      ctx.lineTo(x, height);
      ctx.stroke();

      if (isMajor && s >= 0) {
        ctx.fillStyle = '#64748B';
        ctx.font = '10px "IBM Plex Mono", monospace';
        ctx.textAlign = 'center';
        ctx.fillText(`${s.toFixed(1)}s`, x, height - 6);
      }
    }

    // 2. Draw Horizontal Baselines and Channels
    visibleChannels.forEach((ch, idx) => {
      const centerY = (idx + 0.5) * channelHeight;

      // Baseline
      ctx.beginPath();
      ctx.strokeStyle = '#151D2E';
      ctx.lineWidth = 1;
      ctx.moveTo(0, centerY);
      ctx.lineTo(width, centerY);
      ctx.stroke();

      // Channel label badge
      ctx.fillStyle = '#0E1424';
      ctx.fillRect(8, centerY - 14, 52, 28);
      ctx.strokeStyle = '#1E293B';
      ctx.lineWidth = 1;
      ctx.strokeRect(8, centerY - 14, 52, 28);

      ctx.fillStyle = ch.color;
      ctx.font = '600 11px "IBM Plex Mono", monospace';
      ctx.textAlign = 'left';
      ctx.fillText(ch.name, 14, centerY + 3);

      // Impedance readout in micro-text
      const impStatusColor = ch.impedanceKOhms < 5 ? '#10B981' : ch.impedanceKOhms < 10 ? '#F59E0B' : '#F43F5E';
      ctx.fillStyle = impStatusColor;
      ctx.font = '9px "IBM Plex Mono", monospace';
      ctx.fillText(`${ch.impedanceKOhms.toFixed(1)}kΩ`, 14, centerY + 12);

      // Extract slice for this channel
      const rawValues = signalBuffer[ch.id] || [];
      if (rawValues.length < 2) return;

      const pipeline = filterPipelines.get(ch.id);

      // Scale factor: gainMicroVolts corresponds to half the channel height
      const scaleY = (channelHeight * 0.42) / gainMicroVolts;

      // Draw Raw Trace (quiet if filtered is enabled, or primary)
      if (!showFiltered) {
        ctx.beginPath();
        ctx.strokeStyle = ch.color;
        ctx.lineWidth = 1.3;
        ctx.lineJoin = 'round';

        let firstPoint = true;
        for (let i = 0; i < totalSamples; i++) {
          const t = timeStamps[i] / 1000;
          if (t < startTime) continue;

          const x = ((t - startTime) / timeWindowSec) * width;
          const val = rawValues[i] || 0;
          const y = centerY - val * scaleY;

          if (firstPoint) {
            ctx.moveTo(x, y);
            firstPoint = false;
          } else {
            ctx.lineTo(x, y);
          }
        }
        ctx.stroke();
      } else {
        // Draw Filtered Trace
        ctx.beginPath();
        ctx.strokeStyle = ch.color;
        ctx.lineWidth = 1.4;
        ctx.lineJoin = 'round';

        // Filter on the fly using pipeline
        let firstPoint = true;
        for (let i = 0; i < totalSamples; i++) {
          const t = timeStamps[i] / 1000;
          if (t < startTime) continue;

          const x = ((t - startTime) / timeWindowSec) * width;
          let val = rawValues[i] || 0;
          if (pipeline) {
            val = pipeline.filterSample(val, filterConfig);
          }
          const y = centerY - val * scaleY;

          if (firstPoint) {
            ctx.moveTo(x, y);
            firstPoint = false;
          } else {
            ctx.lineTo(x, y);
          }
        }
        ctx.stroke();
      }
    });

    // 3. Render Marker Events on top
    events.forEach((ev) => {
      const evSec = ev.timestampMs / 1000;
      if (evSec >= startTime && evSec <= latestTime) {
        const x = ((evSec - startTime) / timeWindowSec) * width;

        ctx.beginPath();
        ctx.strokeStyle = ev.code === 102 ? '#F59E0B' : '#06B6D4';
        ctx.lineWidth = 1.5;
        ctx.setLineDash([4, 3]);
        ctx.moveTo(x, 0);
        ctx.lineTo(x, height);
        ctx.stroke();
        ctx.setLineDash([]);

        // Marker tag at top
        ctx.fillStyle = ev.code === 102 ? 'rgba(245, 158, 11, 0.9)' : 'rgba(6, 182, 212, 0.9)';
        ctx.fillRect(x - 2, 4, 94, 18);
        ctx.fillStyle = '#090C15';
        ctx.font = 'bold 9px "IBM Plex Mono", monospace';
        ctx.textAlign = 'left';
        ctx.fillText(ev.code === 102 ? 'TARGET S2' : 'BASELINE S1', x + 3, 16);
      }
    });

    // 4. Render Clinical Annotations
    annotations.forEach((ann) => {
      if (ann.timestampSec >= startTime && ann.timestampSec <= latestTime) {
        const x = ((ann.timestampSec - startTime) / timeWindowSec) * width;
        const color = ann.category === 'clinical_event' ? '#EC4899' : ann.category === 'artifact' ? '#EF4444' : '#10B981';

        ctx.beginPath();
        ctx.strokeStyle = color;
        ctx.lineWidth = 2;
        ctx.moveTo(x, 0);
        ctx.lineTo(x, height);
        ctx.stroke();

        // Pin badge
        ctx.fillStyle = color;
        ctx.beginPath();
        ctx.arc(x, 24, 5, 0, Math.PI * 2);
        ctx.fill();

        ctx.fillStyle = '#F8FAFC';
        ctx.font = '10px "Plus Jakarta Sans", sans-serif';
        ctx.textAlign = 'left';
        ctx.fillText(ann.label, x + 8, 28);
      }
    });

    // 5. Draw Crosshair Hover Indicator
    if (hoverInfo) {
      ctx.beginPath();
      ctx.strokeStyle = 'rgba(255, 255, 255, 0.35)';
      ctx.lineWidth = 1;
      ctx.setLineDash([2, 2]);
      ctx.moveTo(hoverInfo.x, 0);
      ctx.lineTo(hoverInfo.x, height);
      ctx.moveTo(0, hoverInfo.y);
      ctx.lineTo(width, hoverInfo.y);
      ctx.stroke();
      ctx.setLineDash([]);

      // Floating probe tooltip
      const tooltipW = 160;
      const tooltipH = 50;
      let tx = hoverInfo.x + 12;
      let ty = hoverInfo.y + 12;
      if (tx + tooltipW > width) tx = hoverInfo.x - tooltipW - 12;
      if (ty + tooltipH > height) ty = hoverInfo.y - tooltipH - 12;

      ctx.fillStyle = 'rgba(14, 19, 34, 0.95)';
      ctx.strokeStyle = '#38BDF8';
      ctx.lineWidth = 1;
      ctx.fillRect(tx, ty, tooltipW, tooltipH);
      ctx.strokeRect(tx, ty, tooltipW, tooltipH);

      ctx.fillStyle = '#38BDF8';
      ctx.font = '600 11px "IBM Plex Mono", monospace';
      ctx.textAlign = 'left';
      ctx.fillText(`${hoverInfo.channelName} · ${hoverInfo.valueUv.toFixed(1)} µV`, tx + 8, ty + 18);

      ctx.fillStyle = '#94A3B8';
      ctx.font = '10px "IBM Plex Mono", monospace';
      ctx.fillText(`T = ${hoverInfo.timeSec.toFixed(3)}s`, tx + 8, ty + 34);
    }

    ctx.restore();
  }, [
    visibleChannels,
    timeStamps,
    timeWindowSec,
    signalBuffer,
    filterPipelines,
    filterConfig,
    showFiltered,
    gainMicroVolts,
    events,
    annotations,
    hoverInfo,
  ]);

  // Frame render loop
  useEffect(() => {
    let animId: number;
    const loop = () => {
      renderCanvas();
      animId = requestAnimationFrame(loop);
    };
    animId = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(animId);
  }, [renderCanvas]);

  // Handle canvas mouse move for interactive probe
  const handleMouseMove = (e: React.MouseEvent<HTMLCanvasElement>) => {
    const canvas = canvasRef.current;
    if (!canvas || visibleChannels.length === 0 || timeStamps.length < 2) return;

    const rect = canvas.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;

    const channelHeight = rect.height / visibleChannels.length;
    const channelIndex = Math.min(
      visibleChannels.length - 1,
      Math.max(0, Math.floor(y / channelHeight))
    );
    const targetChannel = visibleChannels[channelIndex];

    const totalSamples = timeStamps.length;
    const latestTime = timeStamps[totalSamples - 1] / 1000;
    const startTime = Math.max(0, latestTime - timeWindowSec);

    const timeRatio = x / rect.width;
    const probeTimeSec = startTime + timeRatio * timeWindowSec;

    // Find nearest sample
    let nearestIdx = 0;
    let minDiff = Infinity;
    for (let i = 0; i < totalSamples; i++) {
      const diff = Math.abs(timeStamps[i] / 1000 - probeTimeSec);
      if (diff < minDiff) {
        minDiff = diff;
        nearestIdx = i;
      }
    }

    const channelVals = signalBuffer[targetChannel.id] || [];
    const val = channelVals[nearestIdx] || 0;

    setHoverInfo({
      x,
      y,
      timeSec: probeTimeSec,
      channelName: targetChannel.name,
      valueUv: val,
    });
  };

  const handleMouseLeave = () => {
    setHoverInfo(null);
  };

  const handleCanvasClick = (e: React.MouseEvent<HTMLCanvasElement>) => {
    if (!hoverInfo) return;
    onAddAnnotation(hoverInfo.timeSec, hoverInfo.channelName);
  };

  return (
    <div className="flex flex-col h-full bg-[#090C15] border border-slate-800 rounded-lg overflow-hidden">
      {/* Precision Telemetry Ribbon & Controls */}
      <div className="flex flex-wrap items-center justify-between gap-3 px-4 py-2.5 bg-[#0E1322] border-b border-slate-800 text-xs">
        {/* Playback Controls & Status */}
        <div className="flex items-center gap-2">
          <button
            onClick={onTogglePlay}
            className={`flex items-center gap-1.5 px-3 py-1.5 font-medium rounded transition-colors whitespace-nowrap ${
              isPlaying
                ? 'bg-amber-500/10 text-amber-400 border border-amber-500/30 hover:bg-amber-500/20'
                : 'bg-emerald-500 text-slate-950 font-semibold hover:bg-emerald-400'
            }`}
          >
            {isPlaying ? (
              <>
                <Pause className="w-3.5 h-3.5" />
                <span>Pause Stream</span>
              </>
            ) : (
              <>
                <Play className="w-3.5 h-3.5" />
                <span>Live Stream</span>
              </>
            )}
          </button>

          <button
            onClick={onReset}
            title="Clear buffer and reset sweep"
            className="p-1.5 text-slate-400 hover:text-slate-200 hover:bg-slate-800/60 rounded transition-colors"
          >
            <RotateCcw className="w-3.5 h-3.5" />
          </button>

          <div className="h-4 w-px bg-slate-800 mx-1" />

          {/* Time & Calibration Status */}
          <div className="flex items-center gap-2 text-slate-400 font-mono-data">
            <span className="flex items-center gap-1.5">
              <span className={`w-2 h-2 rounded-full ${isPlaying ? 'bg-emerald-400 animate-pulse' : 'bg-slate-500'}`} />
              <span className="text-slate-300 font-semibold">{isPlaying ? 'ACQUIRING' : 'IDLE'}</span>
            </span>
            <span aria-hidden="true">·</span>
            <span>{samplingRate} Hz</span>
            <span aria-hidden="true">·</span>
            <span>{(timeStamps[timeStamps.length - 1] / 1000 || 0).toFixed(2)}s ELAPSED</span>
          </div>
        </div>

        {/* Lobe / Derivation Filter Bar */}
        <div className="flex items-center gap-1 p-0.5 bg-slate-900 border border-slate-800 rounded">
          {['ALL', 'Frontal', 'Central', 'Parietal', 'Occipital', 'Muscle'].map((lobe) => (
            <button
              key={lobe}
              onClick={() => setActiveLobeFilter(lobe)}
              className={`px-2.5 py-1 text-xs font-medium rounded transition-colors whitespace-nowrap ${
                activeLobeFilter === lobe
                  ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/30'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              {lobe}
            </button>
          ))}
        </div>

        {/* Display Settings: Gain, Time Window, Filter Mode */}
        <div className="flex items-center gap-2">
          {/* Signal Mode Toggle */}
          <button
            onClick={() => setShowFiltered(!showFiltered)}
            className={`flex items-center gap-1.5 px-2.5 py-1 rounded border text-xs font-mono-data transition-colors whitespace-nowrap ${
              showFiltered
                ? 'bg-cyan-950/60 border-cyan-500/40 text-cyan-300'
                : 'bg-slate-900 border-slate-800 text-slate-400 hover:text-slate-200'
            }`}
          >
            <Sliders className="w-3 h-3 text-cyan-400" />
            <span>{showFiltered ? 'FILTERED (0.5-45Hz)' : 'RAW INPUT'}</span>
          </button>

          {/* Time Window Selector */}
          <div className="flex items-center gap-1 bg-slate-900 border border-slate-800 px-2 py-1 rounded text-slate-300 font-mono-data">
            <span className="text-slate-500 text-[11px]">SWEEP:</span>
            {[2, 5, 10].map((sec) => (
              <button
                key={sec}
                onClick={() => setTimeWindowSec(sec)}
                className={`px-1.5 py-0.5 rounded text-[11px] ${
                  timeWindowSec === sec ? 'bg-slate-700 text-white font-semibold' : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                {sec}s
              </button>
            ))}
          </div>

          {/* Gain Scaling */}
          <div className="flex items-center gap-1 bg-slate-900 border border-slate-800 px-2 py-1 rounded text-slate-300 font-mono-data">
            <span className="text-slate-500 text-[11px]">GAIN:</span>
            {[25, 50, 100].map((gain) => (
              <button
                key={gain}
                onClick={() => setGainMicroVolts(gain)}
                className={`px-1.5 py-0.5 rounded text-[11px] ${
                  gainMicroVolts === gain ? 'bg-slate-700 text-white font-semibold' : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                {gain}µV
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Main Multi-Channel Canvas Stage */}
      <div ref={containerRef} className="relative flex-1 w-full overflow-hidden cursor-crosshair">
        <canvas
          ref={canvasRef}
          onMouseMove={handleMouseMove}
          onMouseLeave={handleMouseLeave}
          onClick={handleCanvasClick}
          className="w-full h-full block"
        />

        {/* Quick Channel Contact Matrix Overlay on bottom-left */}
        <div className="absolute bottom-2 left-2 flex items-center gap-1 bg-[#0E1322]/90 backdrop-blur-sm border border-slate-800/80 px-2.5 py-1 rounded text-[11px] text-slate-400 pointer-events-auto">
          <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
          <span className="font-mono-data">ELECTRODE IMPEDANCE NOMINAL (&lt;5kΩ)</span>
          <span className="text-slate-600">|</span>
          <span className="text-slate-300">CLICK CANVAS TO ANNOTATE</span>
        </div>
      </div>

      {/* Channel Toggles Bar */}
      <div className="flex items-center gap-1 px-3 py-1.5 bg-[#090D18] border-t border-slate-800 overflow-x-auto text-[11px] font-mono-data">
        <span className="text-slate-500 uppercase tracking-wider text-[10px] shrink-0 mr-1">CHANNELS:</span>
        {channels.map((ch) => {
          const isToggled = toggledChannels[ch.id] !== false;
          return (
            <button
              key={ch.id}
              onClick={() => toggleChannel(ch.id)}
              className={`flex items-center gap-1 px-2 py-0.5 rounded border transition-colors whitespace-nowrap shrink-0 ${
                isToggled
                  ? 'bg-slate-800/80 border-slate-700 text-slate-200'
                  : 'bg-slate-950/40 border-slate-900 text-slate-600 line-through'
              }`}
            >
              <span className="w-2 h-2 rounded-full" style={{ backgroundColor: isToggled ? ch.color : '#475569' }} />
              <span>{ch.name}</span>
            </button>
          );
        })}
      </div>
    </div>
  );
};
